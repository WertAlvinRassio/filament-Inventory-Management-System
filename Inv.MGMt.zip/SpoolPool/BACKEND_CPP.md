# C++ Backend Core

This project now keeps Flask routes and the web UI unchanged, while moving core backend business logic into a C++ extension module (`filament_native`).

## What moved to C++

- Text clamping and input normalization
- Calibration status calculation (365-day validity)
- NFC payload parsing (`Brand|Color|Type|Tare`)
- NFC payload formatting for writes
- Weight computation from raw ADC + calibration + tare
- New-roll requirement checks
- Calibration validation and factor calculation

## Build/install

On Raspberry Pi (or Linux with build tools):

```bash
pip3 install --break-system-packages pybind11
pip3 install --break-system-packages .
```

`install.sh` already performs this during one-click setup.

## Runtime behavior

- Flask endpoints remain the same.
- UI behavior remains the same.
- If the compiled extension cannot be imported, `filament_core_bridge.py` falls back to equivalent Python logic so the app can still start.
