#include <pybind11/pybind11.h>
#include <cmath>
#include <iomanip>
#include <optional>
#include <sstream>
#include <string>
#include <vector>

namespace py = pybind11;

namespace {

std::string trim(const std::string& in) {
    const auto start = in.find_first_not_of(" \t\n\r");
    if (start == std::string::npos) {
        return "";
    }
    const auto end = in.find_last_not_of(" \t\n\r");
    return in.substr(start, end - start + 1);
}

std::string clamp_text_cpp(const std::string& s, std::size_t max_len = 32) {
    const auto t = trim(s);
    if (t.size() <= max_len) {
        return t;
    }
    return t.substr(0, max_len);
}

std::optional<double> to_optional_double(const py::object& obj) {
    if (obj.is_none()) {
        return std::nullopt;
    }
    try {
        return obj.cast<double>();
    } catch (...) {
        return std::nullopt;
    }
}

std::string calibration_status_cpp(const py::object& last_calibrated_obj) {
    if (last_calibrated_obj.is_none()) {
        return "Not calibrated";
    }
    std::string value;
    try {
        value = last_calibrated_obj.cast<std::string>();
    } catch (...) {
        return "Not calibrated";
    }
    if (trim(value).empty()) {
        return "Not calibrated";
    }

    py::module_ datetime = py::module_::import("datetime");
    py::object timezone = datetime.attr("timezone");
    py::object timedelta = datetime.attr("timedelta");
    py::object dt_cls = datetime.attr("datetime");

    try {
        std::string normalized = value;
        const auto z_pos = normalized.find('Z');
        if (z_pos != std::string::npos) {
            normalized.replace(z_pos, 1, "+00:00");
        }

        py::object dt = dt_cls.attr("fromisoformat")(normalized);
        if (dt.attr("tzinfo").is_none()) {
            dt = dt.attr("replace")(py::arg("tzinfo") = timezone.attr("utc"));
        }

        py::object now_utc = dt_cls.attr("now")(timezone.attr("utc"));
        py::object elapsed = now_utc - dt;
        py::object one_year = timedelta(py::arg("days") = 365);
        if (py::cast<bool>(elapsed > one_year)) {
            return "Not calibrated";
        }
        return "Calibrated";
    } catch (...) {
        return "Not calibrated";
    }
}

py::dict parse_nfc_payload_cpp(const std::string& text) {
    py::dict out;
    out["parsed_any"] = false;
    out["brand"] = py::none();
    out["color"] = py::none();
    out["type"] = py::none();
    out["tare"] = py::none();
    out["nfc_needs_programming"] = true;

    const auto trimmed = trim(text);
    if (trimmed.empty()) {
        return out;
    }

    std::vector<std::string> parts;
    std::string token;
    std::stringstream ss(trimmed);
    while (std::getline(ss, token, '|')) {
        parts.push_back(trim(token));
    }

    bool parsed_any = false;
    if (parts.size() >= 3 && !parts[0].empty() && !parts[1].empty() && !parts[2].empty()) {
        out["brand"] = parts[0];
        out["color"] = parts[1];
        out["type"] = parts[2];
        parsed_any = true;
    }

    if (parts.size() >= 4 && !parts[3].empty()) {
        try {
            out["tare"] = std::stod(parts[3]);
        } catch (...) {
            out["tare"] = py::none();
        }
    }

    out["parsed_any"] = parsed_any;
    out["nfc_needs_programming"] = !parsed_any;
    return out;
}

py::dict build_nfc_payload_cpp(
    const std::string& brand_in,
    const std::string& color_in,
    const std::string& filament_type_in,
    const py::object& tare_obj,
    const std::string& current_brand,
    const std::string& current_color,
    const std::string& current_type
) {
    const auto brand = clamp_text_cpp(brand_in.empty() ? current_brand : brand_in);
    const auto color = clamp_text_cpp(color_in.empty() ? current_color : color_in);
    const auto filament_type = clamp_text_cpp(filament_type_in.empty() ? current_type : filament_type_in);

    std::string tare_str;
    py::object tare_out = py::none();
    const auto tare_val = to_optional_double(tare_obj);
    if (tare_val.has_value()) {
        std::ostringstream ss;
        ss << std::fixed << std::setprecision(2) << *tare_val;
        tare_str = ss.str();
        while (!tare_str.empty() && tare_str.back() == '0') {
            tare_str.pop_back();
        }
        if (!tare_str.empty() && tare_str.back() == '.') {
            tare_str.pop_back();
        }
        tare_out = py::float_(*tare_val);
    }

    py::dict out;
    out["brand"] = brand;
    out["color"] = color;
    out["type"] = filament_type;
    out["tare"] = tare_out;
    out["tare_str"] = tare_str;
    out["payload"] = brand + "|" + color + "|" + filament_type + "|" + tare_str;
    return out;
}

py::dict compute_weight_cpp(
    const py::object& raw_obj,
    double zero_offset_raw,
    double calibration_factor,
    const py::object& tag_tare_obj,
    bool had_uid,
    bool was_active
) {
    py::dict out;
    if (raw_obj.is_none()) {
        out["gross_weight"] = 0.0;
        out["weight"] = 0.0;
        out["is_active"] = false;
        return out;
    }

    const double raw = raw_obj.cast<double>();
    double gross = 0.0;
    if (calibration_factor != 0.0) {
        gross = (raw - zero_offset_raw) / calibration_factor;
    }

    if (gross < 0.0 && gross > -50.0) {
        gross = 0.0;
    }

    double tare = 0.0;
    const auto tare_opt = to_optional_double(tag_tare_obj);
    // Apply NFC tare only when a tag is currently present.
    if (had_uid && tare_opt.has_value()) {
        tare = *tare_opt;
    }

    double net = gross - tare;
    if (gross < 0.0) {
        gross = 0.0;
    }
    if (net < 0.0) {
        net = 0.0;
    }
    bool is_active = was_active;
    if (gross > 0.0 || had_uid) {
        is_active = true;
    }

    out["gross_weight"] = gross;
    out["weight"] = net;
    out["is_active"] = is_active;
    return out;
}

py::dict validate_calibration_cpp(
    const py::object& raw_obj,
    double zero_offset_raw,
    const py::object& known_weight_obj
) {
    py::dict out;
    out["success"] = false;

    const auto known = to_optional_double(known_weight_obj);
    if (!known.has_value() || *known <= 0.0) {
        out["error"] = "known_weight must be > 0";
        return out;
    }

    if (raw_obj.is_none()) {
        out["error"] = "Unable to read load cell";
        return out;
    }

    const double raw = raw_obj.cast<double>();
    if (raw == 0.0) {
        out["error"] = "Unable to read load cell";
        return out;
    }

    if (zero_offset_raw == 0.0) {
        out["error"] = "Zero not set. Remove all weight, wait 2-3s, then click Zero Scale.";
        return out;
    }

    const double delta = raw - zero_offset_raw;
    if (std::abs(delta) < 200.0) {
        out["error"] = "Reading change too small/unstable";
        out["known_weight"] = *known;
        out["raw"] = raw;
        out["zero"] = zero_offset_raw;
        out["delta"] = delta;
        out["hint"] = "Make sure the known weight is actually on the platform (not touching frame), wait 3-5s, then try again. If delta stays near 0, the NAU7802 is not seeing the bridge signal (wiring/E+/E-/A+/A- or mechanical mount).";
        return out;
    }

    const double factor = delta / *known;
    if (factor == 0.0) {
        out["error"] = "Bad calibration factor";
        return out;
    }

    out["success"] = true;
    out["factor"] = factor;
    out["raw"] = raw;
    out["zero"] = zero_offset_raw;
    out["delta"] = delta;
    out["known_weight"] = *known;
    return out;
}

bool requires_new_roll_check_cpp(double gross_weight, const py::object& uid_obj, bool nfc_needs_programming) {
    bool has_uid = false;
    if (!uid_obj.is_none()) {
        try {
            const auto uid = uid_obj.cast<std::string>();
            has_uid = !uid.empty();
        } catch (...) {
            has_uid = false;
        }
    }
    return gross_weight >= 10.0 && (!has_uid || nfc_needs_programming);
}

}  // namespace

PYBIND11_MODULE(filament_native, m) {
    m.doc() = "C++ backend core for filament inventory business logic";

    m.def("clamp_text", &clamp_text_cpp, py::arg("text"), py::arg("max_len") = 32);
    m.def("calibration_status", &calibration_status_cpp, py::arg("last_calibrated"));
    m.def("parse_nfc_payload", &parse_nfc_payload_cpp, py::arg("text"));
    m.def(
        "build_nfc_payload",
        &build_nfc_payload_cpp,
        py::arg("brand"),
        py::arg("color"),
        py::arg("filament_type"),
        py::arg("tare"),
        py::arg("current_brand"),
        py::arg("current_color"),
        py::arg("current_type")
    );
    m.def(
        "compute_weight",
        &compute_weight_cpp,
        py::arg("raw"),
        py::arg("zero_offset_raw"),
        py::arg("calibration_factor"),
        py::arg("tag_tare"),
        py::arg("had_uid"),
        py::arg("was_active")
    );
    m.def(
        "validate_calibration",
        &validate_calibration_cpp,
        py::arg("raw"),
        py::arg("zero_offset_raw"),
        py::arg("known_weight")
    );
    m.def(
        "requires_new_roll_check",
        &requires_new_roll_check_cpp,
        py::arg("gross_weight"),
        py::arg("uid"),
        py::arg("nfc_needs_programming")
    );
}
