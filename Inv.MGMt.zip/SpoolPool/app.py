#!/usr/bin/env python3
"""FilaWizard Filament Inventory (Rebuilt Backend)

- Uses adafruit_tca9548a for PCA9548 I2C mux management
- Uses cedargrove_nau7802 driver for NAU7802 24-bit ADC
- Uses adafruit_hdc302x for HDC302x temperature/humidity sensor
- Uses adafruit_pn532 for PN532 NFC via NAU7802 second STEMMA QT port
- Auto-detects active mux channels and disables unused connections
- Per mux channel map:
  - Channels 0-5: NAU7802 load cell + PN532 NFC reader slots
  - Channel 6: HDC302x environmental sensor
  - Channel 7: reserved for downstream mux link
- Keeps existing UI + NFC format + calibration + Excel export + history
- Prevents silent 500s: API endpoints return JSON with error details

NFC payload format:
  Brand|Color|Type|Tare
"""

from __future__ import annotations

import io
import json
import logging
import os
import sys
import threading
import time
import copy
from dataclasses import dataclass
from datetime import datetime
from typing import Optional, Tuple, Dict, Any, List

from flask import Flask, jsonify, render_template, request, send_file

# Hardware libs (Pi)
HARDWARE_AVAILABLE = True
HARDWARE_IMPORT_ERROR: Optional[str] = None
try:
    import board
    import busio
    import adafruit_tca9548a
    import adafruit_hdc302x
    from cedargrove_nau7802 import NAU7802
    from adafruit_pn532.i2c import PN532_I2C
except Exception as e:
    HARDWARE_AVAILABLE = False
    HARDWARE_IMPORT_ERROR = str(e)
    board = None
    busio = None
    adafruit_tca9548a = None
    adafruit_hdc302x = None
    NAU7802 = None
    PN532_I2C = None

import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
import filament_core_bridge as cpp_backend

log = logging.getLogger("filawizard")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stderr,
)

# ---------------------------
# Configuration
# ---------------------------

APP_TITLE = "FilaWizard"
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(BASE_DIR, "inventory_config.json")
HISTORY_FILE = os.path.join(BASE_DIR, "history.jsonl")

PCA9548_ADDRESSES = [0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77]

# Per-mux channel mapping
HDC302X_ADDR = 0x44
HDC302X_CHANNEL = 6
DOWNSTREAM_MUX_CHANNEL = 7
SLOT_CHANNELS = tuple(range(0, 6))

# Device addresses
NAU7802_ADDR = 0x2A
PN532_ADDR = 0x24

# Business logic
LOW_FILAMENT_THRESHOLD_G = 250
NEW_ROLL_DEFAULT_G = 1000

# Loop
SCAN_INTERVAL_SEC = 0.5

# Stable muxed NAU7802 read tuning
NAU_WARMUP_READS = 20
NAU_FILTER_SAMPLES = 30
NAU_SAMPLE_DELAY_SEC = 0.03

# UI-facing weight stabilization
WEIGHT_HOLD_THRESHOLD_G = 3.0
WEIGHT_SMOOTHING_ALPHA = 0.35
WEIGHT_STEP_SNAP_THRESHOLD_G = 25.0
NFC_MISS_GRACE_POLLS = 4
NFC_READ_ERROR_REINIT_THRESHOLD = 3
NFC_READ_TIMEOUT_SEC = 0.18
NFC_READ_ATTEMPTS_PER_SCAN = 4
NFC_READ_RETRY_DELAY_SEC = 0.04
NFC_WEIGHT_TRIGGER_DELTA_G = 15.0
NFC_PERIODIC_REFRESH_SEC = 8.0
NFC_EMPTY_SLOT_REFRESH_SEC = 0.75
NFC_BLANK_TAG_REFRESH_SEC = 2.0
NFC_STABLE_UID_REFRESH_SEC = 12.0
NFC_CLEAR_WEIGHT_THRESHOLD_G = 10.0
NFC_NO_UID_REFRESH_SEC = 2.0
STARTUP_WARMUP_PASSES = 3
STARTUP_WARMUP_DELAY_SEC = 0.35
NFC_UID_PAYLOAD_RETRY_POLLS = 4
HARDWARE_RECOVERY_INTERVAL_SEC = 5.0
ENV_SENSOR_RETRY_INTERVAL_SEC = 10.0
NFC_DISCOVERY_SWEEP_INTERVAL_SEC = 4.0

# Default slots based on per-mux mapping (8 muxes x 6 slot channels).
DEFAULT_SLOT_COUNT = int(os.environ.get("SLOT_COUNT", str(len(PCA9548_ADDRESSES) * len(SLOT_CHANNELS))))

# ---------------------------
# Helpers
# ---------------------------

def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")

def safe_float(v) -> Optional[float]:
    if v is None or v == "":
        return None
    try:
        return float(v)
    except Exception:
        return None

def clamp_text(s: str, max_len: int = 32) -> str:
    return cpp_backend.clamp_text(s or "", max_len)

def calibration_status(last_calibrated: Optional[str]) -> str:
    return cpp_backend.calibration_status(last_calibrated)

def append_history(event: Dict[str, Any]) -> None:
    try:
        with open(HISTORY_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(event, ensure_ascii=False) + "\n")
    except Exception:
        pass


class SafeMuxChannel:
    """Busio-compatible mux channel wrapper that always releases the root I2C lock.

    Adafruit's ``TCA9548A_Channel`` can leave the underlying bus locked when a
    muxed device disappears during a transaction. This wrapper selects the mux
    channel manually and guarantees deselect/unlock cleanup even on hot-swap
    errors from downstream devices.
    """

    def __init__(self, i2c: busio.I2C, mux_address: int, channel: int):
        self._i2c = i2c
        self._mux_address = int(mux_address)
        self._channel = int(channel)
        self._mask = bytes([1 << self._channel])
        self._locked = False

    def try_lock(self) -> bool:
        if self._locked:
            return True
        if not self._i2c.try_lock():
            return False
        try:
            self._i2c.writeto(self._mux_address, self._mask)
            self._locked = True
            return True
        except Exception:
            try:
                self._i2c.unlock()
            except Exception:
                pass
            return False

    def unlock(self) -> None:
        if not self._locked:
            return
        try:
            try:
                self._i2c.writeto(self._mux_address, b"\x00")
            except Exception:
                pass
        finally:
            self._locked = False
            try:
                self._i2c.unlock()
            except Exception:
                pass

    def writeto(self, address: int, buffer, *, start: int = 0, end: Optional[int] = None, stop: bool = True) -> None:
        if not self._locked:
            raise RuntimeError("I2C channel must be locked before writeto")
        try:
            self._i2c.writeto(address, buffer, start=start, end=end, stop=stop)
        except TypeError as e:
            if "unexpected keyword argument 'stop'" not in str(e):
                raise
            self._i2c.writeto(address, buffer, start=start, end=end)

    def readfrom_into(self, address: int, buffer, *, start: int = 0, end: Optional[int] = None) -> None:
        if not self._locked:
            raise RuntimeError("I2C channel must be locked before readfrom_into")
        self._i2c.readfrom_into(address, buffer, start=start, end=end)

    def writeto_then_readfrom(
        self,
        address: int,
        out_buffer,
        in_buffer,
        *,
        out_start: int = 0,
        out_end: Optional[int] = None,
        in_start: int = 0,
        in_end: Optional[int] = None,
        stop: bool = False,
    ) -> None:
        if not self._locked:
            raise RuntimeError("I2C channel must be locked before writeto_then_readfrom")
        try:
            self._i2c.writeto_then_readfrom(
                address,
                out_buffer,
                in_buffer,
                out_start=out_start,
                out_end=out_end,
                in_start=in_start,
                in_end=in_end,
                stop=stop,
            )
        except TypeError as e:
            if "unexpected keyword argument 'stop'" not in str(e):
                raise
            self._i2c.writeto_then_readfrom(
                address,
                out_buffer,
                in_buffer,
                out_start=out_start,
                out_end=out_end,
                in_start=in_start,
                in_end=in_end,
            )

# ---------------------------
# Load cell (NAU7802 via cedargrove driver)
# ---------------------------

class NAU7802LoadCell:
    """Wrapper around cedargrove_nau7802 NAU7802 driver for load cell reading
    through a TCA9548A mux channel.  The TCA9548A driver handles mux channel
    switching transparently when devices are created with tca[channel]."""

    def __init__(self, tca_channel, address=NAU7802_ADDR):
        self.tca_channel = tca_channel
        self.address = address
        self.available = False
        self.initialized = False
        self.last_error = None
        self._nau = None
        self._init_device()

    def _init_device(self):
        """Initialize the NAU7802 using the cedargrove driver.
        The constructor handles: reset, enable, LDO 3V0, gain 128, 10 SPS."""
        try:
            self._nau = NAU7802(self.tca_channel, address=self.address, active_channels=1)
            # Perform internal offset calibration
            if not self._nau.calibrate("INTERNAL"):
                self.last_error = "NAU7802 internal calibration failed"
                self._nau = None
                return

            self.available = True
            self.initialized = True

            # Discard warmup reads to let the ADC stabilize
            for _ in range(10):
                if self._nau.available():
                    self._nau.read()
                time.sleep(0.01)

        except Exception as e:
            self.last_error = str(e)
            self.available = False
            self.initialized = False
            self._nau = None

    def data_ready(self) -> bool:
        """Check if ADC conversion data is ready."""
        if not self._nau:
            return False
        try:
            return self._nau.available()
        except Exception:
            return False

    def read_raw_once(self) -> Optional[float]:
        """Read a single ADC value.  Returns signed value or None."""
        if not (self.available and self.initialized and self._nau):
            return None
        try:
            timeout = 100
            while not self._nau.available() and timeout > 0:
                time.sleep(0.02)
                timeout -= 1
            if timeout <= 0:
                return None
            return self._nau.read()
        except Exception as e:
            self.last_error = str(e)
            return None

    def read_filtered_raw(self) -> Optional[float]:
        """Read ADC with warmup and median filtering for stable results."""
        if not (self.available and self.initialized):
            return None

        # Warmup reads (discarded)
        for _ in range(NAU_WARMUP_READS):
            self.read_raw_once()
            time.sleep(NAU_SAMPLE_DELAY_SEC)

        # Collect filtered samples
        vals = []
        for _ in range(NAU_FILTER_SAMPLES):
            v = self.read_raw_once()
            if v is not None:
                vals.append(v)
            time.sleep(NAU_SAMPLE_DELAY_SEC)

        if not vals:
            return None

        vals.sort()
        return vals[len(vals) // 2]

# ---------------------------
# Slot + Config
# ---------------------------

@dataclass
class SlotConfig:
    # counts-per-gram (raw delta / grams)
    calibration_factor: float = 1.0
    # raw reading at zero load
    zero_offset_raw: float = 0.0
    last_calibrated: Optional[str] = None


class UnavailableSlot:
    """Placeholder slot returned when hardware startup failed."""

    def __init__(self, slot_id: int, error: str):
        self.slot_id = int(slot_id)
        self.uid: Optional[str] = None
        self.has_scale = False
        self.has_nfc = False
        self.hardware_present = False
        self.nfc_needs_programming = False
        self.last_error = error
        self.cfg = SlotConfig()

    def get_data(self) -> Dict[str, Any]:
        return {
            "slot_id": self.slot_id,
            "hardware_present": False,
            "has_scale": False,
            "has_nfc": False,
            "uid": None,
            "paired_uid": None,
            "requires_new_roll_check": False,
            "nfc_needs_programming": False,
            "brand": "Unknown",
            "color": "N/A",
            "type": "N/A",
            "tare": None,
            "raw_nfc_text": None,
            "gross_weight": 0.0,
            "weight": 0.0,
            "is_active": False,
            "calibration_factor": float(self.cfg.calibration_factor),
            "last_calibrated": self.cfg.last_calibrated,
            "calibration_status": "Not calibrated",
            "calibration_required": True,
            "last_error": self.last_error,
        }

    def read_weight(self) -> float:
        return 0.0

    def reset_weight_tracking(self) -> None:
        return

    def write_tag(self, brand: str, color: str, filament_type: str, tare: Optional[float]) -> bool:
        return False

    def dump_ntag_pages(self, start_page: int = 4, end_page: int = 19) -> Dict[str, Any]:
        return {"success": False, "error": self.last_error, "pages": []}

    def raw_ultralight_compare(self, start_page: int = 4, end_page: int = 7) -> Dict[str, Any]:
        return {"success": False, "error": self.last_error, "pages": []}

    def raw_ultralight_write(self, page: int, data_hex: str) -> Dict[str, Any]:
        return {"success": False, "error": self.last_error, "page": int(page)}

    def set_new_roll(self, full_roll_g: float, manual_tare: Optional[float] = None) -> bool:
        return False

class FilamentSlot:
    """Represents a single filament slot with NAU7802 load cell and PN532 NFC,
    accessed through a TCA9548A mux channel.  The PN532 is connected via the
    NAU7802's second STEMMA QT passthrough port on the same mux channel."""

    def __init__(self, slot_id: int, tca_channel, cfg: SlotConfig):
        self.slot_id = slot_id
        self.tca_channel = tca_channel
        self.cfg = cfg

        # Initialize NAU7802 load cell via cedargrove driver
        self.nau7802 = NAU7802LoadCell(tca_channel=tca_channel, address=NAU7802_ADDR)
        self.nfc: Optional[PN532_I2C] = None

        self.has_scale = bool(self.nau7802.available)
        self.nfc_available = False
        self.has_nfc = False
        self.hardware_present = bool(self.has_scale)

        # Hotplug tracking (RAM-only)
        self._was_present = self.hardware_present
        self._disconnect_seen = False

        # NFC / material state
        self.uid: Optional[str] = None
        self._last_good_uid: Optional[str] = None
        self.filament_brand = "Unknown"
        self.filament_color = "N/A"
        self.filament_type = "N/A"
        self.tag_tare: Optional[float] = None
        self.nfc_needs_programming = False
        self.raw_nfc_text: Optional[str] = None
        self._nfc_miss_count = 0
        self._nfc_error_count = 0
        self._nfc_refresh_required = True
        self._last_nfc_poll_gross_weight: Optional[float] = None
        self._last_nfc_poll_monotonic: Optional[float] = None
        self._nfc_payload_retry_polls = 0
        self._last_payload_uid: Optional[str] = None

        self.gross_weight = 0.0
        self.weight = 0.0
        self._smoothed_gross_weight: Optional[float] = None
        self._last_uid_for_weight: Optional[str] = None
        self._last_tare_for_weight: Optional[float] = None
        self.is_active = False
        self.last_error: Optional[str] = None

        # Initialize PN532 NFC on the same mux channel (via NAU7802 second STEMMA QT)
        self._init_nfc()

    @property
    def calibration_factor(self) -> float:
        return float(self.cfg.calibration_factor or 1.0)

    def _init_nfc(self) -> None:
        """Initialize PN532 NFC reader on the same mux channel as the NAU7802.
        The PN532 is connected via the NAU7802's second STEMMA QT passthrough."""
        try:
            self.nfc = PN532_I2C(self.tca_channel, debug=False, address=PN532_ADDR)
            self.nfc.SAM_configuration()
            time.sleep(0.05)
            self.nfc_available = True
            self.has_nfc = True
            self._nfc_error_count = 0
            self._nfc_refresh_required = True
        except Exception as e:
            self.nfc = None
            self.nfc_available = False
            self.has_nfc = False
            self.last_error = f"NFC init: {e}"
        finally:
            self.hardware_present = bool(self.has_scale or self.has_nfc)
            self._was_present = self.hardware_present

    def _read_ntag_text_range(self, start_page: int, end_page: int) -> Optional[str]:
        if not self.nfc_available or not self.nfc:
            return None
        try:
            raw = bytearray()
            for page in range(int(start_page), int(end_page) + 1):
                page_bytes = self._read_ntag_page(page)
                if page_bytes is None:
                    break
                raw.extend(page_bytes)
            return self._decode_ntag_payload(bytes(raw))
        except Exception:
            return None

    def _decode_ntag_payload(self, raw: bytes) -> Optional[str]:
        if not raw:
            return None

        def _clean_text(data: bytes) -> str:
            return data.decode("utf-8", errors="ignore").split("\x00", 1)[0].strip()

        plain = _clean_text(raw)
        if cpp_backend.parse_nfc_payload(plain or "").get("parsed_any"):
            return plain

        try:
            tlv_start = raw.find(b"\x03")
            if tlv_start != -1 and tlv_start + 2 < len(raw):
                ndef_len = raw[tlv_start + 1]
                ndef_start = tlv_start + 2
                ndef_end = min(len(raw), ndef_start + ndef_len)
                ndef = raw[ndef_start:ndef_end]
                if len(ndef) >= 5 and ndef[0] in (0xD1, 0x91):
                    type_len = ndef[1]
                    payload_len = ndef[2]
                    payload_start = 3 + type_len
                    if payload_start < len(ndef):
                        payload = ndef[payload_start:payload_start + payload_len]
                        if payload and ndef[3:3 + type_len] == b"T":
                            status = payload[0] if payload else 0
                            lang_len = status & 0x3F
                            text_bytes = payload[1 + lang_len:]
                            text = _clean_text(text_bytes)
                            if text:
                                return text
                        text = _clean_text(payload)
                        if text:
                            return text
        except Exception:
            pass

        return plain or None

    def _read_ntag_text(self) -> Optional[str]:
        """Read custom text payload, with fallback for older page-4 tags.

        Newer tags store plain text starting at page 5 to avoid clobbering
        common NTAG TLV bytes on page 4. Older tags in the field may still
        have been written starting at page 4, so we try both layouts.
        """
        text = self._read_ntag_text_range(5, 19)
        if cpp_backend.parse_nfc_payload(text or "").get("parsed_any"):
            return text

        legacy_text = self._read_ntag_text_range(4, 19)
        if cpp_backend.parse_nfc_payload(legacy_text or "").get("parsed_any"):
            return legacy_text

        return text or legacy_text

    def _write_ntag_text(self, text: str) -> bool:
        """Write custom text payload to user pages 5-19 (60 bytes max)."""
        if not self.nfc_available or not self.nfc:
            return False
        payload = (text or "").encode("utf-8")[:59] + b"\x00"
        page_count = min(15, max(1, (len(payload) + 3) // 4))
        payload = payload + b"\x00" * (page_count * 4 - len(payload))
        try:
            for i in range(page_count):
                chunk = payload[i * 4:(i + 1) * 4]
                page = 5 + i
                page_written = False
                for _ in range(3):
                    if not self._write_ntag_page(page, chunk):
                        time.sleep(0.03)
                        continue
                    time.sleep(0.03)
                    verify = self._read_ntag_page(page)
                    if verify is not None and bytes(verify) == bytes(chunk):
                        page_written = True
                        break
                    time.sleep(0.03)
                if not page_written:
                    self.last_error = f"Failed to verify NFC page {page}"
                    return False
            return True
        except Exception as e:
            self.last_error = f"NFC page write error: {e}"
            return False

    def _clear_tag_state(self) -> None:
        """Forget tag-specific state when no NFC tag is present on this slot."""
        self.uid = None
        self._last_good_uid = None
        self.filament_brand = "Unknown"
        self.filament_color = "N/A"
        self.filament_type = "N/A"
        self.tag_tare = None
        self.nfc_needs_programming = False
        self.raw_nfc_text = None
        self._nfc_miss_count = 0
        self._last_uid_for_weight = None
        self._last_tare_for_weight = None
        self._last_nfc_poll_gross_weight = None
        self._last_nfc_poll_monotonic = None
        self._nfc_payload_retry_polls = 0
        self._last_payload_uid = None

    def should_refresh_nfc(self) -> bool:
        """Poll NFC on startup, after meaningful weight changes, and periodically."""
        if self._nfc_refresh_required:
            return True
        if self._nfc_payload_retry_polls > 0:
            return True
        now = time.monotonic()
        if self._last_nfc_poll_monotonic is None:
            return True
        elapsed = now - self._last_nfc_poll_monotonic
        current_gross = float(self.gross_weight or 0.0)
        if self._last_nfc_poll_gross_weight is None:
            return True
        # If there is meaningful weight on the slot but no UID, poll more eagerly
        # so newly placed tags get picked up quickly without forcing a full scan
        # on every single backend loop.
        if current_gross >= 10.0 and not self.uid:
            return elapsed >= NFC_EMPTY_SLOT_REFRESH_SEC
        if not self.uid:
            return elapsed >= NFC_NO_UID_REFRESH_SEC
        # Once a tagged roll is removed and the platform is effectively empty,
        # accelerate re-checks so stale NFC data clears from the UI promptly.
        if self.uid and current_gross < NFC_CLEAR_WEIGHT_THRESHOLD_G:
            return elapsed >= NFC_EMPTY_SLOT_REFRESH_SEC
        if current_gross >= NFC_CLEAR_WEIGHT_THRESHOLD_G and self.uid and self._nfc_miss_count > 0:
            return elapsed >= NFC_EMPTY_SLOT_REFRESH_SEC
        if self.uid and self.nfc_needs_programming:
            return elapsed >= NFC_BLANK_TAG_REFRESH_SEC
        if self.uid and self.uid == self._last_good_uid:
            return elapsed >= NFC_STABLE_UID_REFRESH_SEC
        if elapsed >= NFC_PERIODIC_REFRESH_SEC:
            return True
        return abs(current_gross - self._last_nfc_poll_gross_weight) >= NFC_WEIGHT_TRIGGER_DELTA_G

    def _mark_nfc_fault(self, message: str) -> None:
        """Record repeated PN532 failures and force re-init after a few errors."""
        self.last_error = message
        self._nfc_error_count += 1
        if self._nfc_error_count < NFC_READ_ERROR_REINIT_THRESHOLD:
            return
        self.nfc = None
        self.nfc_available = False
        self.has_nfc = False
        self._nfc_refresh_required = True
        self._clear_tag_state()

    def refresh_hardware(self) -> None:
        """Re-probe hardware and handle hotplug events."""
        prev = self._was_present

        # Re-init scale if it went away
        if not self.nau7802.available:
            self.nau7802 = NAU7802LoadCell(tca_channel=self.tca_channel, address=NAU7802_ADDR)
        self.has_scale = bool(self.nau7802.available)

        # Re-init NFC if it went away
        if not self.nfc_available:
            self._init_nfc()
        self.has_nfc = bool(self.nfc_available)

        self.hardware_present = bool(self.has_scale or self.has_nfc)

        if prev and not self.hardware_present:
            self._disconnect_seen = True
        if self._disconnect_seen and (not prev) and self.hardware_present:
            # Preserve calibration across brief hardware dropouts. In practice
            # the mux/NFC path can blip even though the load cell setup did not
            # physically change, and clearing calibration here causes the UI to
            # flip back to "Calibration required" immediately after calibration.
            self._disconnect_seen = False

        self._was_present = self.hardware_present

    def read_nfc(self) -> bool:
        """Read NFC tag UID and payload.  The TCA9548A driver handles mux
        channel selection transparently."""
        if not self.nfc_available or not self.nfc:
            self._clear_tag_state()
            self.has_nfc = False
            self.hardware_present = bool(self.has_scale or self.has_nfc)
            return False

        try:
            previous_uid = self.uid
            uid_bytes = None
            for attempt in range(NFC_READ_ATTEMPTS_PER_SCAN):
                uid_bytes = self.nfc.read_passive_target(timeout=NFC_READ_TIMEOUT_SEC)
                if uid_bytes:
                    break
                if attempt + 1 < NFC_READ_ATTEMPTS_PER_SCAN:
                    time.sleep(NFC_READ_RETRY_DELAY_SEC)
            self._last_nfc_poll_gross_weight = float(self.gross_weight or 0.0)
            self._last_nfc_poll_monotonic = time.monotonic()
            self._nfc_refresh_required = False
            if not uid_bytes:
                self._nfc_miss_count += 1
                current_gross = float(self.gross_weight or 0.0)
                if self._nfc_miss_count <= NFC_MISS_GRACE_POLLS:
                    return bool(self.uid)
                if current_gross >= NFC_CLEAR_WEIGHT_THRESHOLD_G and self.uid:
                    self._nfc_refresh_required = True
                    return True
                self._clear_tag_state()
                if abs(self.weight) < NFC_CLEAR_WEIGHT_THRESHOLD_G:
                    self.is_active = False
                return False

            self.uid = "".join(f"{b:02X}" for b in uid_bytes)
            uid_changed = self.uid != previous_uid
            self._nfc_miss_count = 0
            self._nfc_error_count = 0
            self.is_active = True
            if uid_changed:
                self._nfc_payload_retry_polls = NFC_UID_PAYLOAD_RETRY_POLLS
                self.raw_nfc_text = None

            should_read_payload = bool(
                uid_changed
                or self._nfc_payload_retry_polls > 0
                or self.uid != self._last_payload_uid
                or self.raw_nfc_text is None
                or self.nfc_needs_programming
            )
            if not should_read_payload and self.uid == self._last_good_uid:
                self.last_error = None
                return True

            txt = self._read_ntag_text()
            self.raw_nfc_text = txt
            self._last_payload_uid = self.uid
            parsed = cpp_backend.parse_nfc_payload(txt or "")
            parsed_any = bool(parsed.get("parsed_any"))

            if parsed_any:
                if parsed.get("brand"):
                    self.filament_brand = parsed["brand"]
                if parsed.get("color"):
                    self.filament_color = parsed["color"]
                if parsed.get("type"):
                    self.filament_type = parsed["type"]
                self.tag_tare = parsed.get("tare")
                self.nfc_needs_programming = bool(parsed.get("nfc_needs_programming", True))
                self._last_good_uid = self.uid
                self._nfc_payload_retry_polls = 0
                self.last_error = None
            elif self.uid != self._last_good_uid:
                self.filament_brand = "Unknown"
                self.filament_color = "N/A"
                self.filament_type = "N/A"
                self.tag_tare = None
                self.nfc_needs_programming = True
                self._nfc_payload_retry_polls = max(0, self._nfc_payload_retry_polls - 1)
                self._nfc_refresh_required = self._nfc_payload_retry_polls > 0
                self.last_error = None
            else:
                self._nfc_payload_retry_polls = 0
                self.last_error = None

            return True
        except Exception as e:
            self._mark_nfc_fault(f"NFC read: {e}")
            return False

    def ensure_tag_present(self, attempts: int = 3, delay_sec: float = 0.15) -> bool:
        """Force a fresh NFC poll before operations that require a live tag."""
        if not self.nfc_available or not self.nfc:
            self.last_error = "NFC reader is not available"
            self._clear_tag_state()
            return False

        for attempt in range(max(1, int(attempts))):
            if self.read_nfc() and self.uid:
                return True
            if attempt + 1 < attempts:
                time.sleep(delay_sec)

        self.last_error = "No NFC tag detected. Hold the tag on the reader and try again."
        self._clear_tag_state()
        return False

    def read_weight(self):
        """Read filtered weight from the NAU7802 load cell."""
        if not self.nau7802.available:
            self.weight = 0.0
            self.gross_weight = 0.0
            self._smoothed_gross_weight = None
            self._last_uid_for_weight = None
            self._last_tare_for_weight = None
            return 0.0

        raw = self.nau7802.read_filtered_raw()

        if raw is None:
            self.weight = 0.0
            self.gross_weight = 0.0
            self._smoothed_gross_weight = None
            self._last_uid_for_weight = None
            self._last_tare_for_weight = None
            return 0.0

        calc = cpp_backend.compute_weight(
            raw=raw,
            zero_offset_raw=float(self.cfg.zero_offset_raw or 0.0),
            calibration_factor=float(self.calibration_factor or 0.0),
            tag_tare=self.tag_tare,
            had_uid=bool(self.uid),
            was_active=bool(self.is_active),
        )
        new_gross = float(calc.get("gross_weight") or 0.0)
        current_uid = self.uid
        current_tare = float(self.tag_tare) if self.tag_tare is not None else None

        if current_uid != self._last_uid_for_weight or current_tare != self._last_tare_for_weight:
            self._smoothed_gross_weight = new_gross
            self._last_uid_for_weight = current_uid
            self._last_tare_for_weight = current_tare

        if self._smoothed_gross_weight is None:
            self._smoothed_gross_weight = new_gross
        else:
            delta_gross = abs(new_gross - self._smoothed_gross_weight)
            if delta_gross <= WEIGHT_HOLD_THRESHOLD_G:
                new_gross = self._smoothed_gross_weight
            elif delta_gross >= WEIGHT_STEP_SNAP_THRESHOLD_G:
                self._smoothed_gross_weight = new_gross
            else:
                self._smoothed_gross_weight = (
                    WEIGHT_SMOOTHING_ALPHA * new_gross
                    + (1.0 - WEIGHT_SMOOTHING_ALPHA) * self._smoothed_gross_weight
                )
            new_gross = self._smoothed_gross_weight

        self.gross_weight = float(new_gross)
        tare_g = current_tare if (current_uid and current_tare is not None) else 0.0
        self.weight = max(0.0, float(self.gross_weight) - float(tare_g))
        self.is_active = bool(calc.get("is_active"))

        return self.weight

    def reset_weight_tracking(self) -> None:
        """Reset smoothed/runtime weight state after zero or calibration."""
        self.gross_weight = 0.0
        self.weight = 0.0
        self._smoothed_gross_weight = None
        self._last_uid_for_weight = None
        self._last_tare_for_weight = None
        self._nfc_refresh_required = True
        self._last_nfc_poll_gross_weight = None

    def write_tag(self, brand: str, color: str, filament_type: str, tare: Optional[float]) -> bool:
        if not self.ensure_tag_present():
            return False

        if tare is None:
            tare = self.tag_tare

        built = cpp_backend.build_nfc_payload(
            brand=brand or "",
            color=color or "",
            filament_type=filament_type or "",
            tare=tare,
            current_brand=self.filament_brand or "Unknown",
            current_color=self.filament_color or "N/A",
            current_type=self.filament_type or "N/A",
        )
        payload = built["payload"]
        ok = self._write_ntag_text(payload)
        if ok:
            expected_brand = built["brand"]
            expected_color = built["color"]
            expected_type = built["type"]
            expected_tare = built.get("tare")

            # Give the tag a moment to settle, then retry readback a few times.
            for attempt in range(3):
                if attempt:
                    time.sleep(0.12)
                readback_text = self._read_ntag_text()
                self.raw_nfc_text = readback_text
                parsed = cpp_backend.parse_nfc_payload(readback_text or "")
                readback_ok = bool(
                    parsed.get("parsed_any")
                    and parsed.get("brand") == expected_brand
                    and parsed.get("color") == expected_color
                    and parsed.get("type") == expected_type
                    and (
                        (parsed.get("tare") is None and expected_tare is None)
                        or (
                            parsed.get("tare") is not None
                            and expected_tare is not None
                            and abs(float(parsed.get("tare")) - float(expected_tare)) < 0.05
                        )
                    )
                )
                if readback_ok:
                    self.filament_brand = expected_brand
                    self.filament_color = expected_color
                    self.filament_type = expected_type
                    self.tag_tare = expected_tare
                    self.nfc_needs_programming = False
                    self._last_good_uid = self.uid
                    self._last_payload_uid = self.uid
                    self._nfc_payload_retry_polls = 0
                    self._nfc_refresh_required = False
                    self.is_active = True
                    self.last_error = None
                    return True

            self.nfc_needs_programming = True
            self.last_error = f"Write verify failed. Read back: {self.raw_nfc_text!r}"
            return False

        if not self.last_error:
            self.last_error = "Failed to write NFC payload to tag"
        return False

    def dump_ntag_pages(self, start_page: int = 4, end_page: int = 19) -> Dict[str, Any]:
        """Read tag memory page-by-page for diagnostics."""
        if not self.ensure_tag_present():
            return {"success": False, "error": self.last_error or "No NFC tag detected"}

        pages: List[Dict[str, Any]] = []
        try:
            for page in range(int(start_page), int(end_page) + 1):
                data = self.nfc.ntag2xx_read_block(page)
                if not data:
                    pages.append({"page": page, "ok": False, "data_hex": None, "ascii": None})
                    continue
                chunk = bytes(data[:4])
                ascii_text = "".join(chr(b) if 32 <= b <= 126 else "." for b in chunk)
                pages.append({
                    "page": page,
                    "ok": True,
                    "data_hex": chunk.hex().upper(),
                    "ascii": ascii_text,
                })
            return {
                "success": True,
                "uid": self.uid,
                "raw_nfc_text": self._read_ntag_text(),
                "pages": pages,
            }
        except Exception as e:
            self.last_error = f"NFC dump: {e}"
            return {"success": False, "error": self.last_error, "uid": self.uid, "pages": pages}

    def _pn532_in_data_exchange(self, payload: bytes, response_length: int) -> Optional[bytes]:
        """Send a raw InDataExchange command to the selected tag."""
        if not self.nfc_available or not self.nfc:
            return None
        call = getattr(self.nfc, "call_function", None)
        if not callable(call):
            self.last_error = "PN532 call_function unavailable"
            return None
        try:
            resp = call(
                0x40,
                params=[0x01, *payload],
                response_length=response_length,
                timeout=1,
            )
            return bytes(resp) if resp is not None else None
        except Exception as e:
            self.last_error = f"PN532 raw exchange failed: {e}"
            return None

    def _read_ntag_page(self, page: int) -> Optional[bytes]:
        """Read a single 4-byte page using raw Ultralight READ."""
        resp = self._pn532_in_data_exchange(bytes([0x30, int(page) & 0xFF]), response_length=17)
        if not resp or resp[0] != 0x00 or len(resp) < 5:
            return None
        return bytes(resp[1:5])

    def _write_ntag_page(self, page: int, data: bytes) -> bool:
        """Write a single 4-byte page using raw Ultralight WRITE."""
        if len(data) != 4:
            return False
        resp = self._pn532_in_data_exchange(bytes([0xA2, int(page) & 0xFF]) + bytes(data), response_length=1)
        return bool(resp and resp[0] == 0x00)

    def raw_ultralight_read(self, page: int) -> Dict[str, Any]:
        """Read 4 pages (16 bytes) using a raw Mifare Ultralight READ command."""
        if not self.ensure_tag_present():
            return {"success": False, "error": self.last_error or "No NFC tag detected"}
        resp = self._pn532_in_data_exchange(bytes([0x30, int(page) & 0xFF]), response_length=17)
        if not resp:
            return {"success": False, "error": self.last_error or "No response", "page": page, "uid": self.uid}

        status = resp[0]
        data = resp[1:]
        return {
            "success": status == 0x00 and len(data) == 16,
            "page": int(page),
            "uid": self.uid,
            "status": int(status),
            "data_hex": data.hex().upper(),
            "ascii": "".join(chr(b) if 32 <= b <= 126 else "." for b in data),
        }

    def raw_ultralight_write(self, page: int, data_hex: str) -> Dict[str, Any]:
        """Write one 4-byte page using a raw Mifare Ultralight WRITE command."""
        if not self.ensure_tag_present():
            return {"success": False, "error": self.last_error or "No NFC tag detected"}
        try:
            payload = bytes.fromhex((data_hex or "").strip())
        except ValueError:
            return {"success": False, "error": "data_hex must be exactly 8 hex chars"}
        if len(payload) != 4:
            return {"success": False, "error": "data_hex must be exactly 8 hex chars"}

        resp = self._pn532_in_data_exchange(bytes([0xA2, int(page) & 0xFF]) + payload, response_length=1)
        if not resp:
            return {"success": False, "error": self.last_error or "No response", "page": page, "uid": self.uid}

        status = resp[0]
        verify = self.raw_ultralight_read(page)
        return {
            "success": status == 0x00 and bool(verify.get("success")) and verify.get("data_hex", "").startswith(payload.hex().upper()),
            "page": int(page),
            "uid": self.uid,
            "status": int(status),
            "wrote_hex": payload.hex().upper(),
            "verify": verify,
        }

    def raw_ultralight_compare(self, start_page: int = 4, end_page: int = 7) -> Dict[str, Any]:
        """Compare helper reads with raw InDataExchange Ultralight reads."""
        if not self.ensure_tag_present():
            return {"success": False, "error": self.last_error or "No NFC tag detected"}

        pages: List[Dict[str, Any]] = []
        for page in range(int(start_page), int(end_page) + 1):
            helper = None
            try:
                block = self.nfc.ntag2xx_read_block(page)
                if block:
                    helper_bytes = bytes(block[:16])
                    helper = {
                        "ok": True,
                        "data_hex": helper_bytes.hex().upper(),
                        "ascii": "".join(chr(b) if 32 <= b <= 126 else "." for b in helper_bytes),
                    }
                else:
                    helper = {"ok": False, "data_hex": None, "ascii": None}
            except Exception as e:
                helper = {"ok": False, "error": str(e), "data_hex": None, "ascii": None}

            raw = self.raw_ultralight_read(page)
            pages.append({"page": page, "helper": helper, "raw": raw})

        return {"success": True, "uid": self.uid, "pages": pages}

    def set_new_roll(self, full_roll_g: float, manual_tare: Optional[float] = None) -> bool:
        if manual_tare is not None:
            tare = max(0.0, float(manual_tare))
        else:
            tare = max(0.0, float(self.gross_weight) - float(full_roll_g))
        return self.write_tag(self.filament_brand, self.filament_color, self.filament_type, tare)

    def get_data(self) -> Dict[str, Any]:
        cal_stat = calibration_status(self.cfg.last_calibrated)
        is_calibrated = bool(
            cal_stat == "Calibrated"
            or self.cfg.last_calibrated
            or abs(float(self.calibration_factor or 1.0) - 1.0) > 0.0001
        )
        return {
            "slot_id": self.slot_id,
            "hardware_present": bool(self.hardware_present),
            "has_scale": bool(self.has_scale),
            "has_nfc": bool(self.has_nfc),
            "uid": self.uid,
            "paired_uid": None,
            "requires_new_roll_check": cpp_backend.requires_new_roll_check(
                gross_weight=float(self.gross_weight or 0.0),
                uid=self.uid,
                nfc_needs_programming=bool(self.nfc_needs_programming),
            ),
            "nfc_needs_programming": bool(self.nfc_needs_programming),
            "brand": self.filament_brand,
            "color": self.filament_color,
            "type": self.filament_type,
            "tare": self.tag_tare,
            "raw_nfc_text": self.raw_nfc_text,
            "gross_weight": round(float(self.gross_weight or 0.0), 1),
            "weight": round(float(self.weight or 0.0), 1),
            "is_active": bool(self.is_active),
            "calibration_factor": float(self.calibration_factor),
            "last_calibrated": self.cfg.last_calibrated,
            "calibration_status": ("Calibrated" if is_calibrated else "Not calibrated"),
            "calibration_required": (not is_calibrated),
            "last_error": self.last_error,
        }

# ---------------------------
# Inventory Manager
# ---------------------------

class InventoryManager:
    """Manages all filament slots across one or more PCA9548 muxes.

    On startup:
      1. Probes PCA9548_ADDRESSES to find connected muxes (via adafruit_tca9548a).
      2. Scans every channel on every mux for known device addresses.
      3. Builds FilamentSlot objects only for channels with a NAU7802.
      4. Creates an HDC302x sensor instance for the designated env channel.
      5. Disables (deselects) all channels that have no active devices.
    """

    def __init__(self, i2c: busio.I2C):
        self.lock = threading.Lock()
        self.i2c = i2c

        # Discover connected PCA9548 muxes.
        # TCA9548A.__init__ does NOT probe the hardware — it always succeeds.
        # We must verify each address exists on the bus first, otherwise
        # TCA9548A_Channel.try_lock() will acquire the I2C lock, then raise
        # OSError on writeto, permanently leaking the lock and deadlocking.
        self.muxes: List[adafruit_tca9548a.TCA9548A] = []
        for addr in PCA9548_ADDRESSES:
            try:
                while not i2c.try_lock():
                    pass
                try:
                    i2c.writeto(addr, b"\x00")  # deselect all channels
                finally:
                    i2c.unlock()
                tca = adafruit_tca9548a.TCA9548A(i2c, address=addr)
                self.muxes.append(tca)
                log.info("Found PCA9548 mux at 0x%02X", addr)
            except OSError:
                log.debug("No mux at 0x%02X", addr)
            except Exception as e:
                log.debug("No mux at 0x%02X: %s", addr, e)

        # Active channel map: (mux_index, channel) -> list of detected device names
        self.active_channels: Dict[Tuple[int, int], List[str]] = {}
        self._scan_all_channels()

        # Environmental sensors (one per mux on channel 6)
        self.sensors: Dict[int, adafruit_hdc302x.HDC302x] = {}
        self.temperature_c: Optional[float] = None
        self.humidity: Optional[float] = None
        self._last_env_sensor_init_attempt = 0.0
        self._init_env_sensor()

        # Config + slots
        self.config = self._load_config()
        self.slots: List[FilamentSlot] = []
        self._build_slots()

        # Disable unused channels
        self._disable_unused_channels()

        self.last_error: Optional[str] = None
        self._snapshot_cache: Dict[str, Any] = {
            "slots": [],
            "active_slots": 0,
            "present_ports": 0,
            "temperature": self.temperature_c,
            "humidity": self.humidity,
            "error": self.last_error,
        }
        self._last_nfc_discovery_sweep = 0.0

    def _refresh_snapshot_cache(self) -> None:
        slots = [s.get_data() for s in self.slots if s.hardware_present]
        self._snapshot_cache = {
            "slots": slots,
            "active_slots": len(slots),
            "present_ports": len(slots),
            "temperature": self.temperature_c,
            "humidity": self.humidity,
            "error": self.last_error,
        }

    # -- Channel detection --

    def _probe_address(self, tca_channel, address: int) -> bool:
        """Attempt a 0-byte write to *address* on *tca_channel* to detect a device.
        TCA9548A_Channel implements the I2C interface (try_lock/unlock/writeto)
        rather than context-manager protocol."""
        try:
            deadline = time.monotonic() + 2.0
            while not tca_channel.try_lock():
                if time.monotonic() > deadline:
                    log.warning("_probe_address: timeout acquiring lock for 0x%02X", address)
                    return False
                time.sleep(0.01)
            try:
                tca_channel.writeto(address, b"")
                return True
            except OSError:
                return False
            finally:
                tca_channel.unlock()
        except Exception as e:
            log.debug("_probe_address 0x%02X exception: %s", address, e)
            return False

    def _scan_all_channels(self) -> None:
        """Probe each mux channel for known device addresses."""
        for mux_idx, tca in enumerate(self.muxes):
            for ch in range(8):
                channel = SafeMuxChannel(self.i2c, tca.address, ch)
                detected: List[str] = []

                if ch == DOWNSTREAM_MUX_CHANNEL:
                    # Reserved for downstream mux link.
                    continue
                elif ch == HDC302X_CHANNEL:
                    if self._probe_address(channel, HDC302X_ADDR):
                        detected.append("hdc302x")
                else:
                    if self._probe_address(channel, NAU7802_ADDR):
                        detected.append("nau7802")
                    if self._probe_address(channel, PN532_ADDR):
                        detected.append("pn532")

                if detected:
                    self.active_channels[(mux_idx, ch)] = detected
                    log.info("  mux[%d] ch%d: %s", mux_idx, ch, detected)

    def _disable_unused_channels(self) -> None:
        """Deselect all mux channels by writing 0x00 to each mux's control
        register.  Active channels are re-selected on demand by the TCA9548A
        driver when downstream devices are accessed.

        We use the raw I2C bus directly (same safe pattern as mux discovery)
        instead of TCA9548A_Channel.try_lock(), which can leak the I2C lock
        if writeto raises on a flaky bus."""
        for mux_idx, tca in enumerate(self.muxes):
            try:
                while not self.i2c.try_lock():
                    pass
                try:
                    self.i2c.writeto(tca.address, b"\x00")
                finally:
                    self.i2c.unlock()
            except Exception as e:
                log.debug("Failed to deselect mux[%d]: %s", mux_idx, e)

    # -- Environmental sensor --

    def _init_env_sensor(self) -> None:
        """Initialize one HDC302x sensor per mux on channel 6."""
        self._last_env_sensor_init_attempt = time.monotonic()
        self.sensors = {}
        for mux_idx, tca in enumerate(self.muxes):
            try:
                tca_channel = SafeMuxChannel(self.i2c, tca.address, HDC302X_CHANNEL)
                self.sensors[mux_idx] = adafruit_hdc302x.HDC302x(tca_channel, address=HDC302X_ADDR)
                self.active_channels[(mux_idx, HDC302X_CHANNEL)] = ["hdc302x"]
                log.info("Activated HDC302x on mux[%d] ch%d", mux_idx, HDC302X_CHANNEL)
            except Exception as e:
                log.warning("HDC302x init failed on mux[%d] ch%d: %s", mux_idx, HDC302X_CHANNEL, e)

    def _ensure_env_sensor(self) -> None:
        if self.sensors:
            return
        if (time.monotonic() - self._last_env_sensor_init_attempt) < ENV_SENSOR_RETRY_INTERVAL_SEC:
            return
        self._init_env_sensor()

    def _read_env_sensor(self) -> None:
        """Read temperature and humidity from all detected HDC302x sensors."""
        self._ensure_env_sensor()
        if not self.sensors:
            self.temperature_c = None
            self.humidity = None
            return
        temps: List[float] = []
        hums: List[float] = []
        failed_muxes: List[int] = []
        for mux_idx, sensor in self.sensors.items():
            try:
                t = sensor.temperature
                h = sensor.relative_humidity
                if t is not None:
                    temps.append(float(t))
                if h is not None:
                    hums.append(float(h))
            except Exception:
                failed_muxes.append(mux_idx)
                continue
        for mux_idx in failed_muxes:
            self.sensors.pop(mux_idx, None)
        self.temperature_c = (sum(temps) / len(temps)) if temps else None
        self.humidity = (sum(hums) / len(hums)) if hums else None

    # -- Slot management --

    def _get_slot_config(self, slot_id: int) -> SlotConfig:
        cfg = self.config.get(str(slot_id))
        if cfg is not None:
            return cfg
        mux_idx = slot_id // len(SLOT_CHANNELS)
        ch = slot_id % len(SLOT_CHANNELS)
        legacy_slot_id = mux_idx * 8 + ch
        return self.config.get(str(legacy_slot_id), SlotConfig())

    def _create_slot_for_channel(self, mux_idx: int, ch: int) -> Optional[FilamentSlot]:
        if mux_idx < 0 or mux_idx >= len(self.muxes) or ch not in SLOT_CHANNELS:
            return None

        slot_id = mux_idx * len(SLOT_CHANNELS) + ch
        if slot_id in getattr(self, "_slot_map", {}):
            return self._slot_map[slot_id]

        tca = self.muxes[mux_idx]
        tca_channel = SafeMuxChannel(self.i2c, tca.address, ch)
        cfg = self._get_slot_config(slot_id)
        slot = FilamentSlot(slot_id, tca_channel, cfg)
        if not slot.hardware_present:
            log.warning(
                "No hardware detected for slot %d on mux[%d] ch%d (scale_error=%r, slot_error=%r)",
                slot_id,
                mux_idx,
                ch,
                slot.nau7802.last_error,
                slot.last_error,
            )
            return None
        self.slots.append(slot)
        self.slots.sort(key=lambda s: s.slot_id)
        self._slot_map[slot_id] = slot
        log.info("Activated slot %d on mux[%d] ch%d", slot_id, mux_idx, ch)
        return slot

    def _discover_new_slots(self) -> None:
        """Attempt slot initialization on missing channels so hot-added boxes appear live."""
        for mux_idx, tca in enumerate(self.muxes):
            for ch in SLOT_CHANNELS:
                slot_id = mux_idx * len(SLOT_CHANNELS) + ch
                if slot_id in self._slot_map:
                    continue
                slot = self._create_slot_for_channel(mux_idx, ch)
                if slot is None:
                    continue
                detected: List[str] = []
                if slot.has_scale:
                    detected.append("nau7802")
                if slot.has_nfc:
                    detected.append("pn532")
                if detected:
                    self.active_channels[(mux_idx, ch)] = detected

    def _build_slots(self) -> None:
        """Create FilamentSlot objects for channels 0..5 on each mux.

        Slot numbering is contiguous by mux:
          slot_id = mux_idx * 6 + channel

        We also support fallback loading from the legacy slot index layout
        (mux_idx * 8 + channel) when migrating existing config files.
        """
        self._slot_map: Dict[int, FilamentSlot] = {}
        for mux_idx, tca in enumerate(self.muxes):
            for ch in SLOT_CHANNELS:
                slot = self._create_slot_for_channel(mux_idx, ch)
                if slot is None:
                    continue
                detected: List[str] = []
                if slot.has_scale:
                    detected.append("nau7802")
                if slot.has_nfc:
                    detected.append("pn532")
                if detected:
                    self.active_channels[(mux_idx, ch)] = detected

    def _load_config(self) -> Dict[str, SlotConfig]:
        try:
            if not os.path.exists(CONFIG_FILE):
                return {}
            raw = json.loads(open(CONFIG_FILE, "r", encoding="utf-8").read())
            out: Dict[str, SlotConfig] = {}
            for k, v in (raw.get("slots") or {}).items():
                out[str(k)] = SlotConfig(
                    calibration_factor=float(v.get("calibration_factor", 1.0) or 1.0),
                    zero_offset_raw=float(v.get("zero_offset_raw", 0.0) or 0.0),
                    last_calibrated=v.get("last_calibrated"),
                )
            return out
        except Exception:
            return {}

    def _save_config(self) -> None:
        try:
            payload = {"slots": {str(s.slot_id): {
                "calibration_factor": float(s.cfg.calibration_factor),
                "zero_offset_raw": float(s.cfg.zero_offset_raw),
                "last_calibrated": s.cfg.last_calibrated,
            } for s in self.slots}}
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2)
        except Exception:
            pass

    def get_slot(self, slot_id: int) -> FilamentSlot:
        return self._slot_map[int(slot_id)]

    def update_readings(self) -> None:
        with self.lock:
            try:
                self._discover_new_slots()
                self._read_env_sensor()
                for s in self.slots:
                    try:
                        s.refresh_hardware()

                        if not s.hardware_present:
                            s._clear_tag_state()
                            s.is_active = False
                            s.gross_weight = 0.0
                            s.weight = 0.0
                            continue

                        # Always read weight
                        s.read_weight()

                        # Poll NFC per slot when this slot's own state says it is due.
                        if s.should_refresh_nfc():
                            s.read_nfc()

                    except Exception as e:
                        s.last_error = f"slot: {e}"

                now = time.monotonic()
                if now - self._last_nfc_discovery_sweep >= NFC_DISCOVERY_SWEEP_INTERVAL_SEC:
                    for s in self.slots:
                        if not s.hardware_present or not s.has_nfc or s.uid:
                            continue
                        try:
                            s.read_nfc()
                        except Exception as e:
                            s.last_error = f"nfc discovery: {e}"
                    self._last_nfc_discovery_sweep = now

                self._save_config()
                self.last_error = None
                self._refresh_snapshot_cache()

            except Exception as e:
                self.last_error = str(e)
                self._refresh_snapshot_cache()

    def snapshot(self) -> Dict[str, Any]:
        return copy.deepcopy(self._snapshot_cache)


class UnavailableInventoryManager:
    """Degraded-mode inventory used when hardware init is unavailable."""

    def __init__(self, error: str):
        self.lock = threading.Lock()
        self.muxes: List[Any] = []
        self.slots: List[UnavailableSlot] = []
        self.sensors: Dict[int, Any] = {}
        self.temperature_c: Optional[float] = None
        self.humidity: Optional[float] = None
        self.last_error = error
        self._snapshot_cache: Dict[str, Any] = {
            "slots": [],
            "active_slots": 0,
            "present_ports": 0,
            "temperature": None,
            "humidity": None,
            "error": self.last_error,
            "hardware_available": False,
        }

    def _save_config(self) -> None:
        return

    def _refresh_snapshot_cache(self) -> None:
        self._snapshot_cache["error"] = self.last_error

    def get_slot(self, slot_id: int) -> UnavailableSlot:
        return UnavailableSlot(slot_id, self.last_error)

    def update_readings(self) -> None:
        self._snapshot_cache["error"] = self.last_error

    def snapshot(self) -> Dict[str, Any]:
        return copy.deepcopy(self._snapshot_cache)

# ---------------------------
# Flask App + Background Loop
# ---------------------------

app = Flask(__name__)

startup_error: Optional[str] = None
_last_hardware_recovery_attempt = 0.0


def create_inventory_manager() -> tuple[object, Optional[str]]:
    if not HARDWARE_AVAILABLE:
        error = (
            "Hardware libraries unavailable. "
            f"Running without Raspberry Pi hardware support: {HARDWARE_IMPORT_ERROR}"
        )
        log.error(error)
        return UnavailableInventoryManager(error), error

    try:
        i2c = busio.I2C(board.SCL, board.SDA)
        log.info("I2C bus initialized on SCL=%s SDA=%s", board.SCL, board.SDA)
        new_inventory = InventoryManager(i2c)
        log.info(
            "InventoryManager ready: %d mux(es), %d slot(s), env_sensors=%d",
            len(new_inventory.muxes), len(new_inventory.slots), len(new_inventory.sensors),
        )
        return new_inventory, None
    except Exception as e:
        error = (
            "Hardware initialization failed. "
            f"Server is running in degraded mode: {e}"
        )
        log.error(error, exc_info=True)
        log.error("Make sure I2C is enabled: sudo raspi-config nonint do_i2c 0")
        return UnavailableInventoryManager(error), error


def try_recover_inventory(force: bool = False) -> None:
    global inventory, startup_error, _last_hardware_recovery_attempt
    if not HARDWARE_AVAILABLE or isinstance(inventory, InventoryManager):
        return

    now = time.monotonic()
    if not force and (now - _last_hardware_recovery_attempt) < HARDWARE_RECOVERY_INTERVAL_SEC:
        return

    _last_hardware_recovery_attempt = now
    new_inventory, error = create_inventory_manager()
    startup_error = error

    if isinstance(new_inventory, InventoryManager):
        inventory = new_inventory
        log.info("Recovered hardware inventory after degraded startup")
        return

    inventory.last_error = error or inventory.last_error
    inventory._refresh_snapshot_cache()


inventory, startup_error = create_inventory_manager()

_bg_started = False
_bg_lock = threading.Lock()

def start_background_loop() -> None:
    global _bg_started
    with _bg_lock:
        if _bg_started:
            return
        _bg_started = True

    for idx in range(STARTUP_WARMUP_PASSES):
        try:
            try_recover_inventory(force=(idx == 0))
            inventory.update_readings()
        except Exception:
            pass
        if idx + 1 < STARTUP_WARMUP_PASSES:
            time.sleep(STARTUP_WARMUP_DELAY_SEC)

    def loop():
        while True:
            try:
                try_recover_inventory()
                inventory.update_readings()
            except Exception:
                pass
            time.sleep(SCAN_INTERVAL_SEC)

    threading.Thread(target=loop, daemon=True).start()

# Start immediately so it works under `flask run` too.
start_background_loop()

# ---------------------------
# Routes
# ---------------------------

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/inventory")
def api_inventory():
    return jsonify(inventory.snapshot()), 200

@app.route("/api/status")
def api_status():
    snap = inventory.snapshot()
    return jsonify({
        "active_slots": snap.get("active_slots", 0),
        "present_ports": snap.get("present_ports", 0),
        "temperature": snap.get("temperature"),
        "humidity": snap.get("humidity"),
        "error": snap.get("error"),
        "hardware_available": snap.get("hardware_available", True),
    }), 200

@app.route("/api/program_nfc/<int:slot_id>", methods=["POST"])
def api_program_nfc(slot_id: int):
    data = request.get_json(silent=True) or {}
    brand = clamp_text(data.get("brand") or "")
    color = clamp_text(data.get("color") or "")
    filament_type = clamp_text(data.get("type") or "")
    tare = safe_float(data.get("tare"))

    if not brand or not color or not filament_type:
        return jsonify({"success": False, "error": "Brand, color, and type are required"}), 400

    with inventory.lock:
        slot = inventory.get_slot(slot_id)
        ok = slot.write_tag(brand, color, filament_type, tare)
        append_history({"ts": now_iso(), "slot": slot_id, "event": "program_nfc", "ok": ok, "uid": slot.uid})
        body = {"success": ok, "slot": slot.get_data()}
        if not ok:
            body["error"] = slot.last_error or "Failed to write NFC tag"
        return jsonify(body), (200 if ok else 400)

@app.route("/api/rewrite_nfc/<int:slot_id>", methods=["POST"])
def api_rewrite_nfc(slot_id: int):
    return api_program_nfc(slot_id)

@app.route("/api/nfc_dump/<int:slot_id>")
def api_nfc_dump(slot_id: int):
    start_page = request.args.get("start", default=4, type=int)
    end_page = request.args.get("end", default=19, type=int)

    if start_page < 0 or end_page < start_page:
        return jsonify({"success": False, "error": "Invalid page range"}), 400

    with inventory.lock:
        slot = inventory.get_slot(slot_id)
        result = slot.dump_ntag_pages(start_page=start_page, end_page=end_page)
        return jsonify(result), (200 if result.get("success") else 400)

@app.route("/api/nfc_raw_compare/<int:slot_id>")
def api_nfc_raw_compare(slot_id: int):
    start_page = request.args.get("start", default=4, type=int)
    end_page = request.args.get("end", default=7, type=int)

    if start_page < 0 or end_page < start_page:
        return jsonify({"success": False, "error": "Invalid page range"}), 400

    with inventory.lock:
        slot = inventory.get_slot(slot_id)
        result = slot.raw_ultralight_compare(start_page=start_page, end_page=end_page)
        return jsonify(result), (200 if result.get("success") else 400)

@app.route("/api/nfc_raw_write/<int:slot_id>", methods=["POST"])
def api_nfc_raw_write(slot_id: int):
    data = request.get_json(silent=True) or {}
    page = int(data.get("page") or 4)
    data_hex = str(data.get("data_hex") or "")

    with inventory.lock:
        slot = inventory.get_slot(slot_id)
        result = slot.raw_ultralight_write(page=page, data_hex=data_hex)
        return jsonify(result), (200 if result.get("success") else 400)

@app.route("/api/replace_spool/<int:slot_id>", methods=["POST"])
def api_replace_spool(slot_id: int):
    data = request.get_json(silent=True) or {}
    full_roll_g = float(data.get("full_roll_g") or NEW_ROLL_DEFAULT_G)
    manual_tare = safe_float(data.get("manual_tare"))

    with inventory.lock:
        slot = inventory.get_slot(slot_id)
        slot.read_weight()
        ok = slot.set_new_roll(full_roll_g=full_roll_g, manual_tare=manual_tare)
        append_history({"ts": now_iso(), "slot": slot_id, "event": "replace_spool", "ok": ok, "uid": slot.uid, "full_roll_g": full_roll_g})
        return jsonify({"success": ok, "slot": slot.get_data()}), (200 if ok else 400)


@app.route("/api/zero/<int:slot_id>", methods=["POST"])
def api_zero(slot_id: int):
    """Capture current raw reading as zero offset (no load on scale)."""
    try:
        with inventory.lock:
            slot = inventory.get_slot(slot_id)
            if not slot.has_scale:
                return jsonify({"success": False, "error": "Load cell not detected"}), 400
            raw = None
            last_exc = None
            for _ in range(5):
                try:
                    raw = slot.nau7802.read_filtered_raw()
                    break
                except Exception as e:
                    last_exc = e
                    time.sleep(0.02)
            if raw is None:
                return jsonify({"success": False, "error": "Unable to read load cell", "details": str(last_exc) if last_exc else None}), 400
            if raw == 0:
                return jsonify({"success": False, "error": "Unable to read load cell"}), 400
            slot.cfg.zero_offset_raw = float(raw)
            slot.reset_weight_tracking()
            inventory._save_config()
            inventory._refresh_snapshot_cache()
            append_history({"ts": now_iso(), "slot": slot_id, "event": "zero", "raw": raw})
            return jsonify({
                "success": True,
                "zero_offset_raw": slot.cfg.zero_offset_raw,
                "slot": slot.get_data(),
            }), 200
    except Exception as e:
        return jsonify({"success": False, "error": "Zero failed", "details": str(e)}), 500

@app.route("/api/calibrate/<int:slot_id>", methods=["POST"])
def api_calibrate(slot_id: int):
    data = request.get_json(silent=True) or {}
    known_weight = safe_float(data.get("known_weight"))

    with inventory.lock:
        slot = inventory.get_slot(slot_id)
        if not slot.has_scale:
            return jsonify({"success": False, "error": "Load cell not detected"}), 400

        samples = []
        for _ in range(3):
            raw_sample = slot.nau7802.read_filtered_raw()
            if raw_sample is not None:
                samples.append(float(raw_sample))
        raw = None
        if samples:
            samples.sort()
            raw = samples[len(samples) // 2]
        calibration = cpp_backend.validate_calibration(
            raw=raw,
            zero_offset_raw=float(slot.cfg.zero_offset_raw or 0.0),
            known_weight=known_weight,
        )
        if not calibration.get("success"):
            return jsonify(calibration), 400
        factor = float(calibration["factor"])

        slot.cfg.calibration_factor = float(factor)
        slot.cfg.last_calibrated = now_iso()
        slot.reset_weight_tracking()
        inventory._save_config()
        inventory._refresh_snapshot_cache()

        append_history({"ts": now_iso(), "slot": slot_id, "event": "calibrate", "known_weight": known_weight, "factor": slot.cfg.calibration_factor})
        return jsonify({"success": True, "calibration_factor": slot.cfg.calibration_factor, "slot": slot.get_data()}), 200

@app.route("/api/export_csv")
def api_export_csv():
    snap = inventory.snapshot()
    rows = [["Slot","UID","Brand","Type","Color","Gross_g","Tare_g","Net_g","CalStatus","LastCalibrated"]]
    for s in snap.get("slots", []):
        rows.append([
            int(s["slot_id"]) + 1,
            s.get("uid") or "",
            s.get("brand") or "",
            s.get("type") or "",
            s.get("color") or "",
            s.get("gross_weight") or 0,
            s.get("tare") if s.get("tare") is not None else "",
            s.get("weight") or 0,
            s.get("calibration_status") or "",
            s.get("last_calibrated") or "",
        ])

    def esc(v):
        sv = "" if v is None else str(v)
        if any(c in sv for c in [",","\n","\r",'"']):
            sv = sv.replace('"', '""')
            return f'"{sv}"'
        return sv

    csv_text = "\n".join([",".join(esc(c) for c in r) for r in rows])
    buf = io.BytesIO(csv_text.encode("utf-8"))
    return send_file(buf, mimetype="text/csv", as_attachment=True, download_name="inventory_report.csv")

@app.route("/api/export")
def api_export_excel():
    snap = inventory.snapshot()
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Inventory"
    ws.append(["Slot","UID","Brand","Type","Color","Gross (g)","Tare (g)","Net (g)","Calibration","Last Calibrated"])
    for cell in ws[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill("solid", fgColor="DDDDDD")
        cell.alignment = Alignment(horizontal="center")

    for s in snap.get("slots", []):
        ws.append([
            int(s["slot_id"]) + 1,
            s.get("uid") or "",
            s.get("brand") or "",
            s.get("type") or "",
            s.get("color") or "",
            s.get("gross_weight") or 0,
            s.get("tare") if s.get("tare") is not None else "",
            s.get("weight") or 0,
            s.get("calibration_status") or "",
            s.get("last_calibrated") or "",
        ])

    bio = io.BytesIO()
    wb.save(bio)
    bio.seek(0)
    return send_file(bio, mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                     as_attachment=True, download_name="inventory_report.xlsx")

@app.route("/api/export_history")
def api_export_history():
    if not os.path.exists(HISTORY_FILE):
        buf = io.BytesIO(b"")
        return send_file(buf, mimetype="text/plain", as_attachment=True, download_name="history.jsonl")
    return send_file(HISTORY_FILE, mimetype="text/plain", as_attachment=True, download_name="history.jsonl")

# ---------------------------
# Entrypoint
# ---------------------------

if __name__ == "__main__":
    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "5000"))
    app.run(host=host, port=port, debug=False)
