# Hybrid C++ Migration Base (Option 1)

This scaffold keeps the current web UI and Flask API contract while creating a C++ core that can absorb backend responsibilities incrementally.

## What is included

- C++ core domain scaffold:
  - `cpp_system/include/filament/slot.hpp`
  - `cpp_system/include/filament/operations.hpp`
  - `cpp_system/include/filament/inventory_service.hpp`
  - `cpp_system/src/operations.cpp`
  - `cpp_system/src/inventory_service.cpp`
  - `cpp_system/CMakeLists.txt`
  - `cpp_system/examples/core_example.cpp`

- Flask hybrid app entrypoint:
  - `app_hybrid.py`

## Why this is useful

- Frontend remains unchanged (`templates/index.html` still works as-is).
- API endpoints remain unchanged.
- We now have a C++ service/domain layer ready for phased migration.

## Run modes

- Existing production baseline: `app.py`
- Hybrid migration path: `app_hybrid.py`

## Phase plan

1. Move business rules fully into `cpp_system` and expose through a C ABI or pybind bridge.
2. Move hardware drivers behind a C++ hardware adapter (Linux I2C access).
3. Reduce Flask to an API facade (or replace with C++ HTTP server when ready).

## Build C++ scaffold

```bash
cd cpp_system
cmake -S . -B build
cmake --build build
```

The example binary (`filament_core_example`) validates core wiring.
