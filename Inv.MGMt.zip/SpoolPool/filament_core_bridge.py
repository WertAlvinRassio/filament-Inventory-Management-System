"""Bridge for C++ backend logic.

This module loads the compiled `filament_native` extension. If it is not available,
it falls back to Python implementations with identical behavior.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

try:
    import filament_native as _native
except Exception:
    _native = None


def _safe_float(v: Any) -> Optional[float]:
    if v is None or v == "":
        return None
    try:
        return float(v)
    except Exception:
        return None


def clamp_text(text: str, max_len: int = 32) -> str:
    if _native is not None:
        return _native.clamp_text(text or "", max_len)
    return (text or "").strip()[:max_len]


def calibration_status(last_calibrated: Optional[str]) -> str:
    if _native is not None:
        return _native.calibration_status(last_calibrated)
    if not last_calibrated:
        return "Not calibrated"
    try:
        s = last_calibrated.replace("Z", "+00:00")
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        if datetime.now(timezone.utc) - dt > timedelta(days=365):
            return "Not calibrated"
        return "Calibrated"
    except Exception:
        return "Not calibrated"


def parse_nfc_payload(text: str) -> Dict[str, Any]:
    if _native is not None:
        return dict(_native.parse_nfc_payload(text or ""))

    out: Dict[str, Any] = {
        "parsed_any": False,
        "brand": None,
        "color": None,
        "type": None,
        "tare": None,
        "nfc_needs_programming": True,
    }
    txt = (text or "").strip()
    if not txt:
        return out

    parts = [p.strip() for p in txt.split("|")]
    parsed_any = len(parts) >= 3 and bool(parts[0] and parts[1] and parts[2])
    if parsed_any:
        out["brand"], out["color"], out["type"] = parts[0], parts[1], parts[2]
    if len(parts) >= 4 and parts[3] != "":
        out["tare"] = _safe_float(parts[3])

    out["parsed_any"] = parsed_any
    out["nfc_needs_programming"] = not parsed_any
    return out


def build_nfc_payload(
    brand: str,
    color: str,
    filament_type: str,
    tare: Optional[float],
    current_brand: str,
    current_color: str,
    current_type: str,
) -> Dict[str, Any]:
    if _native is not None:
        return dict(
            _native.build_nfc_payload(
                brand or "",
                color or "",
                filament_type or "",
                tare,
                current_brand or "Unknown",
                current_color or "N/A",
                current_type or "N/A",
            )
        )

    b = clamp_text(brand or current_brand or "Unknown")
    c = clamp_text(color or current_color or "N/A")
    t = clamp_text(filament_type or current_type or "N/A")

    tare_str = ""
    tare_out = None
    if tare is not None:
        try:
            tare_out = float(tare)
            tare_str = str(round(tare_out, 2))
        except Exception:
            tare_out = None
            tare_str = ""

    return {
        "brand": b,
        "color": c,
        "type": t,
        "tare": tare_out,
        "tare_str": tare_str,
        "payload": f"{b}|{c}|{t}|{tare_str}",
    }


def compute_weight(
    raw: Optional[float],
    zero_offset_raw: float,
    calibration_factor: float,
    tag_tare: Optional[float],
    had_uid: bool,
    was_active: bool,
) -> Dict[str, Any]:
    if _native is not None:
        return dict(
            _native.compute_weight(
                raw,
                float(zero_offset_raw or 0.0),
                float(calibration_factor or 0.0),
                tag_tare,
                bool(had_uid),
                bool(was_active),
            )
        )

    if raw is None:
        return {"gross_weight": 0.0, "weight": 0.0, "is_active": False}

    counts_per_g = float(calibration_factor or 0.0)
    zero = float(zero_offset_raw or 0.0)
    gross = (raw - zero) / counts_per_g if counts_per_g != 0 else 0.0
    if gross < 0 and gross > -50:
        gross = 0.0

    tare_g = float(tag_tare) if (had_uid and tag_tare is not None) else 0.0
    net = gross - tare_g

    if gross < 0:
        gross = 0.0
    if net < 0:
        net = 0.0

    is_active = bool(was_active or gross > 0 or had_uid)
    return {"gross_weight": float(gross), "weight": float(net), "is_active": is_active}


def validate_calibration(raw: Optional[float], zero_offset_raw: float, known_weight: Any) -> Dict[str, Any]:
    if _native is not None:
        return dict(_native.validate_calibration(raw, float(zero_offset_raw or 0.0), known_weight))

    known = _safe_float(known_weight)
    if not known or known <= 0:
        return {"success": False, "error": "known_weight must be > 0"}
    if raw is None or raw == 0:
        return {"success": False, "error": "Unable to read load cell"}
    zero = float(zero_offset_raw or 0.0)
    if zero == 0.0:
        return {
            "success": False,
            "error": "Zero not set. Remove all weight, wait 2-3s, then click Zero Scale.",
        }

    delta = float(raw) - zero
    if abs(delta) < 200:
        return {
            "success": False,
            "error": "Reading change too small/unstable",
            "known_weight": known,
            "raw": raw,
            "zero": zero,
            "delta": delta,
            "hint": "Make sure the known weight is actually on the platform (not touching frame), wait 3-5s, then try again. If delta stays near 0, the NAU7802 is not seeing the bridge signal (wiring/E+/E-/A+/A- or mechanical mount).",
        }

    factor = delta / float(known)
    if factor == 0:
        return {"success": False, "error": "Bad calibration factor"}

    return {
        "success": True,
        "factor": float(factor),
        "raw": raw,
        "zero": zero,
        "delta": delta,
        "known_weight": known,
    }


def requires_new_roll_check(gross_weight: float, uid: Optional[str], nfc_needs_programming: bool) -> bool:
    if _native is not None:
        return bool(_native.requires_new_roll_check(float(gross_weight or 0.0), uid, bool(nfc_needs_programming)))
    return bool((gross_weight or 0.0) >= 10 and ((not uid) or nfc_needs_programming))
