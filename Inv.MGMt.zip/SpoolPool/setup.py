from setuptools import Extension, setup
import pybind11

ext_modules = [
    Extension(
        "filament_native",
        ["cpp_backend/filament_native.cpp"],
        include_dirs=[pybind11.get_include()],
        language="c++",
        extra_compile_args=["/std:c++17"] if __import__("sys").platform.startswith("win") else ["-std=c++17"],
    )
]

setup(
    name="filament-native",
    version="0.1.0",
    description="C++ backend core for Filament Inventory",
    ext_modules=ext_modules,
)
