#!/usr/bin/env python3
"""Hybrid Flask API scaffold.

Purpose:
- Keep the existing web UI (`templates/index.html`) unchanged.
- Preserve existing route names so frontend JS does not change.
- Provide a migration-ready surface where calls can be routed to a C++ service.

Current mode:
- Delegates to existing `app.py` inventory manager for hardware reads.
- Uses C++ bridge for core business operations where available.

This file is intentionally additive: `app.py` remains the production baseline.
"""

import io
from flask import Flask, jsonify, render_template, request, send_file

import app as legacy
import filament_core_bridge as cpp_backend

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/inventory")
def api_inventory():
    return jsonify(legacy.inventory.snapshot()), 200


@app.route("/api/status")
def api_status():
    snap = legacy.inventory.snapshot()
    return jsonify(
        {
            "active_slots": snap.get("active_slots", 0),
            "present_ports": snap.get("present_ports", 0),
            "temperature": snap.get("temperature"),
            "humidity": snap.get("humidity"),
            "error": snap.get("error"),
        }
    ), 200


@app.route("/api/program_nfc/<int:slot_id>", methods=["POST"])
def api_program_nfc(slot_id: int):
    data = request.get_json(silent=True) or {}
    brand = legacy.clamp_text(data.get("brand") or "")
    color = legacy.clamp_text(data.get("color") or "")
    filament_type = legacy.clamp_text(data.get("type") or "")
    tare = legacy.safe_float(data.get("tare"))

    if not brand or not color or not filament_type:
        return jsonify({"success": False, "error": "Brand, color, and type are required"}), 400

    with legacy.inventory.lock:
        slot = legacy.inventory.get_slot(slot_id)
        ok = slot.write_tag(brand, color, filament_type, tare)
        legacy.append_history(
            {
                "ts": legacy.now_iso(),
                "slot": slot_id,
                "event": "program_nfc",
                "ok": ok,
                "uid": slot.uid,
                "mode": "hybrid",
            }
        )
        body = {"success": ok, "slot": slot.get_data()}
        if not ok:
            body["error"] = slot.last_error or "Failed to write NFC tag"
        return jsonify(body), (200 if ok else 400)


@app.route("/api/rewrite_nfc/<int:slot_id>", methods=["POST"])
def api_rewrite_nfc(slot_id: int):
    return api_program_nfc(slot_id)


@app.route("/api/nfc_dump/<int:slot_id>")
def api_nfc_dump(slot_id: int):
    start_page = request.args.get("start", default=4, type=int)
    end_page = request.args.get("end", default=19, type=int)

    if start_page < 0 or end_page < start_page:
        return jsonify({"success": False, "error": "Invalid page range"}), 400

    with legacy.inventory.lock:
        slot = legacy.inventory.get_slot(slot_id)
        result = slot.dump_ntag_pages(start_page=start_page, end_page=end_page)
        return jsonify(result), (200 if result.get("success") else 400)


@app.route("/api/nfc_raw_compare/<int:slot_id>")
def api_nfc_raw_compare(slot_id: int):
    start_page = request.args.get("start", default=4, type=int)
    end_page = request.args.get("end", default=7, type=int)

    if start_page < 0 or end_page < start_page:
        return jsonify({"success": False, "error": "Invalid page range"}), 400

    with legacy.inventory.lock:
        slot = legacy.inventory.get_slot(slot_id)
        result = slot.raw_ultralight_compare(start_page=start_page, end_page=end_page)
        return jsonify(result), (200 if result.get("success") else 400)


@app.route("/api/nfc_raw_write/<int:slot_id>", methods=["POST"])
def api_nfc_raw_write(slot_id: int):
    data = request.get_json(silent=True) or {}
    page = int(data.get("page") or 4)
    data_hex = str(data.get("data_hex") or "")

    with legacy.inventory.lock:
        slot = legacy.inventory.get_slot(slot_id)
        result = slot.raw_ultralight_write(page=page, data_hex=data_hex)
        return jsonify(result), (200 if result.get("success") else 400)


@app.route("/api/replace_spool/<int:slot_id>", methods=["POST"])
def api_replace_spool(slot_id: int):
    data = request.get_json(silent=True) or {}
    full_roll_g = float(data.get("full_roll_g") or legacy.NEW_ROLL_DEFAULT_G)
    manual_tare = legacy.safe_float(data.get("manual_tare"))

    with legacy.inventory.lock:
        slot = legacy.inventory.get_slot(slot_id)
        slot.read_weight()
        ok = slot.set_new_roll(full_roll_g=full_roll_g, manual_tare=manual_tare)
        legacy.append_history(
            {
                "ts": legacy.now_iso(),
                "slot": slot_id,
                "event": "replace_spool",
                "ok": ok,
                "uid": slot.uid,
                "full_roll_g": full_roll_g,
                "mode": "hybrid",
            }
        )
        return jsonify({"success": ok, "slot": slot.get_data()}), (200 if ok else 400)


@app.route("/api/zero/<int:slot_id>", methods=["POST"])
def api_zero(slot_id: int):
    try:
        with legacy.inventory.lock:
            slot = legacy.inventory.get_slot(slot_id)
            if not slot.has_scale:
                return jsonify({"success": False, "error": "Load cell not detected"}), 400

            raw = None
            last_exc = None
            for _ in range(5):
                try:
                    raw = slot.nau7802.read_filtered_raw()
                    break
                except Exception as e:
                    last_exc = e
                    legacy.time.sleep(0.02)

            if raw is None:
                return jsonify(
                    {
                        "success": False,
                        "error": "Unable to read load cell",
                        "details": str(last_exc) if last_exc else None,
                    }
                ), 400
            if raw == 0:
                return jsonify({"success": False, "error": "Unable to read load cell"}), 400

        slot.cfg.zero_offset_raw = float(raw)
        legacy.inventory._save_config()
        legacy.inventory._refresh_snapshot_cache()
        legacy.append_history({"ts": legacy.now_iso(), "slot": slot_id, "event": "zero", "raw": raw, "mode": "hybrid"})
        return jsonify({"success": True, "zero_offset_raw": slot.cfg.zero_offset_raw}), 200
    except Exception as e:
        return jsonify({"success": False, "error": "Zero failed", "details": str(e)}), 500


@app.route("/api/calibrate/<int:slot_id>", methods=["POST"])
def api_calibrate(slot_id: int):
    data = request.get_json(silent=True) or {}
    known_weight = legacy.safe_float(data.get("known_weight"))

    with legacy.inventory.lock:
        slot = legacy.inventory.get_slot(slot_id)
        if not slot.has_scale:
            return jsonify({"success": False, "error": "Load cell not detected"}), 400

        raw = slot.nau7802.read_filtered_raw()
        result = cpp_backend.validate_calibration(raw, float(slot.cfg.zero_offset_raw or 0.0), known_weight)
        if not result.get("success"):
            return jsonify(result), 400

        slot.cfg.calibration_factor = float(result["factor"])
        slot.cfg.last_calibrated = legacy.now_iso()
        slot.reset_weight_tracking()
        legacy.inventory._save_config()
        legacy.inventory._refresh_snapshot_cache()

        legacy.append_history(
            {
                "ts": legacy.now_iso(),
                "slot": slot_id,
                "event": "calibrate",
                "known_weight": known_weight,
                "factor": slot.cfg.calibration_factor,
                "mode": "hybrid",
            }
        )

        return jsonify({"success": True, "calibration_factor": slot.cfg.calibration_factor, "slot": slot.get_data()}), 200


@app.route("/api/export_csv")
def api_export_csv():
    snap = legacy.inventory.snapshot()
    rows = [["Slot", "UID", "Brand", "Type", "Color", "Gross_g", "Tare_g", "Net_g", "CalStatus", "LastCalibrated"]]
    for s in snap.get("slots", []):
        rows.append(
            [
                int(s["slot_id"]) + 1,
                s.get("uid") or "",
                s.get("brand") or "",
                s.get("type") or "",
                s.get("color") or "",
                s.get("gross_weight") or 0,
                s.get("tare") if s.get("tare") is not None else "",
                s.get("weight") or 0,
                s.get("calibration_status") or "",
                s.get("last_calibrated") or "",
            ]
        )

    def esc(v):
        sv = "" if v is None else str(v)
        if any(c in sv for c in [",", "\n", "\r", '"']):
            sv = sv.replace('"', '""')
            return f'"{sv}"'
        return sv

    csv_text = "\n".join([",".join(esc(c) for c in r) for r in rows])
    buf = io.BytesIO(csv_text.encode("utf-8"))
    return send_file(buf, mimetype="text/csv", as_attachment=True, download_name="inventory_report.csv")


@app.route("/api/export")
def api_export_excel():
    return legacy.api_export_excel()


@app.route("/api/export_history")
def api_export_history():
    return legacy.api_export_history()


if __name__ == "__main__":
    host = legacy.os.environ.get("HOST", "0.0.0.0")
    port = int(legacy.os.environ.get("PORT", "5000"))
    app.run(host=host, port=port, debug=False)
