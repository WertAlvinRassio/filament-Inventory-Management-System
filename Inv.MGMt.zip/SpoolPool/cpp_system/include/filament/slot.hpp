#pragma once

#include <optional>
#include <string>

namespace filament {

struct SlotConfig {
    double calibration_factor = 1.0;
    double zero_offset_raw = 0.0;
    std::string last_calibrated;
};

struct SlotState {
    int slot_id = 0;
    bool hardware_present = false;
    bool has_scale = false;
    bool has_nfc = false;

    std::optional<std::string> uid;
    std::string brand = "Unknown";
    std::string color = "N/A";
    std::string type = "N/A";
    std::optional<double> tare;

    double gross_weight = 0.0;
    double weight = 0.0;
    bool is_active = false;
    bool nfc_needs_programming = false;
    std::string last_error;

    SlotConfig config;
};

}  // namespace filament
