#pragma once

#include "filament/slot.hpp"

#include <optional>
#include <string>

namespace filament {

struct CalibrationResult {
    bool success = false;
    std::string error;
    std::string hint;
    double factor = 0.0;
    double raw = 0.0;
    double zero = 0.0;
    double delta = 0.0;
    double known_weight = 0.0;
};

struct NfcParseResult {
    bool parsed_any = false;
    std::optional<std::string> brand;
    std::optional<std::string> color;
    std::optional<std::string> type;
    std::optional<double> tare;
    bool nfc_needs_programming = true;
};

std::string clamp_text(const std::string& text, std::size_t max_len = 32);
std::string calibration_status(const std::string& last_calibrated);
NfcParseResult parse_nfc_payload(const std::string& payload);
std::string build_nfc_payload(const std::string& brand, const std::string& color, const std::string& type, const std::optional<double>& tare);

void compute_weight(SlotState& slot, std::optional<double> raw);
bool requires_new_roll_check(const SlotState& slot);
CalibrationResult validate_calibration(double raw, double zero, double known_weight);

}  // namespace filament
