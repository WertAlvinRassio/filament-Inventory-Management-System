#pragma once

#include "filament/hardware/hardware_adapter.hpp"
#include "filament/hardware/linux_i2c_bus.hpp"
#include "filament/hardware/tca9548a_mux.hpp"

#include <cstdint>
#include <memory>
#include <optional>
#include <vector>

namespace filament::hardware {

struct LinuxHardwareConfig {
    int i2c_bus_number = 1;
    std::vector<uint8_t> mux_addresses = {0x70, 0x71, 0x72, 0x73, 0x74, 0x75, 0x76, 0x77};

    uint8_t nau7802_address = 0x2A;
    uint8_t pn532_address = 0x24;
    uint8_t hdc302x_address = 0x44;

    int hdc302x_mux_index = 0;
    int hdc302x_channel = 7;
};

class LinuxHardwareAdapter final : public IHardwareAdapter {
public:
    explicit LinuxHardwareAdapter(LinuxHardwareConfig cfg = {});

    bool initialize() override;
    EnvReading read_environment() override;
    std::vector<SlotHardwareSample> scan_slots() override;

private:
    struct MuxRef {
        uint8_t address = 0;
        std::unique_ptr<Tca9548aMux> mux;
    };

private:
    LinuxHardwareConfig cfg_;
    LinuxI2cBus bus_;
    std::vector<MuxRef> muxes_;
    bool initialized_ = false;
};

}  // namespace filament::hardware
