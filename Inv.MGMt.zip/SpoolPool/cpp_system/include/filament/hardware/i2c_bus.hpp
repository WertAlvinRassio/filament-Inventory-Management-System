#pragma once

#include <cstdint>
#include <vector>

namespace filament::hardware {

class II2cBus {
public:
    virtual ~II2cBus() = default;

    virtual bool open(int bus_number) = 0;
    virtual void close() = 0;
    virtual bool is_open() const = 0;

    virtual bool probe(uint8_t address) = 0;
    virtual bool write_bytes(uint8_t address, const std::vector<uint8_t>& data) = 0;
    virtual bool read_bytes(uint8_t address, std::vector<uint8_t>& out, std::size_t size) = 0;
    virtual bool write_then_read(
        uint8_t address,
        const std::vector<uint8_t>& tx,
        std::vector<uint8_t>& rx,
        std::size_t rx_size
    ) = 0;
};

}  // namespace filament::hardware
