#pragma once

#include <optional>
#include <string>
#include <vector>

namespace filament::hardware {

struct EnvReading {
    std::optional<double> temperature_c;
    std::optional<double> humidity_rh;
};

struct SlotHardwareSample {
    int slot_id = 0;
    bool hardware_present = false;
    bool has_scale = false;
    bool has_nfc = false;

    std::optional<double> raw_loadcell;
    std::optional<std::string> uid;
    std::optional<std::string> nfc_payload;
    std::string error;
};

class IHardwareAdapter {
public:
    virtual ~IHardwareAdapter() = default;

    virtual bool initialize() = 0;
    virtual EnvReading read_environment() = 0;
    virtual std::vector<SlotHardwareSample> scan_slots() = 0;
};

}  // namespace filament::hardware
