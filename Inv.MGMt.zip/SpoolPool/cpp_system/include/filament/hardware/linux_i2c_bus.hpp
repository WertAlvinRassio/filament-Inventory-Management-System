#pragma once

#include "filament/hardware/i2c_bus.hpp"

namespace filament::hardware {

class LinuxI2cBus final : public II2cBus {
public:
    LinuxI2cBus() = default;
    ~LinuxI2cBus() override;

    bool open(int bus_number) override;
    void close() override;
    bool is_open() const override;

    bool probe(uint8_t address) override;
    bool write_bytes(uint8_t address, const std::vector<uint8_t>& data) override;
    bool read_bytes(uint8_t address, std::vector<uint8_t>& out, std::size_t size) override;
    bool write_then_read(
        uint8_t address,
        const std::vector<uint8_t>& tx,
        std::vector<uint8_t>& rx,
        std::size_t rx_size
    ) override;

private:
    bool set_slave_address(uint8_t address);

private:
    int fd_ = -1;
    uint8_t current_addr_ = 0;
    bool has_addr_ = false;
};

}  // namespace filament::hardware
