#pragma once

#include "filament/hardware/i2c_bus.hpp"

#include <cstdint>

namespace filament::hardware {

class Tca9548aMux {
public:
    Tca9548aMux(II2cBus& bus, uint8_t address);

    bool deselect_all();
    bool select_channel(uint8_t channel);
    bool probe_on_channel(uint8_t channel, uint8_t device_address);

    uint8_t address() const { return address_; }

private:
    II2cBus& bus_;
    uint8_t address_;
};

}  // namespace filament::hardware
