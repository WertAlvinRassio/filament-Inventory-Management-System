#pragma once

#include "filament/slot.hpp"

#include <map>
#include <optional>
#include <vector>

namespace filament {

class InventoryService {
public:
    explicit InventoryService(int slot_count);

    std::vector<SlotState> snapshot() const;
    std::optional<SlotState> get_slot(int slot_id) const;

    bool upsert_sensor_snapshot(const SlotState& incoming);
    bool apply_program_nfc(int slot_id, const std::string& brand, const std::string& color, const std::string& type, std::optional<double> tare);
    bool apply_replace_spool(int slot_id, double full_roll_g, std::optional<double> manual_tare);
    std::optional<double> apply_zero(int slot_id, double raw);
    std::optional<CalibrationResult> apply_calibrate(int slot_id, double known_weight, double raw);

private:
    std::map<int, SlotState> slots_;
};

}  // namespace filament
