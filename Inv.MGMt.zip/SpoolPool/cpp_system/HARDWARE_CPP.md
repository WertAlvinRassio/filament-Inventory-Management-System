# C++ Hardware Adapter (Phase 1)

You asked to prioritize the hardware layer. This phase adds a Linux I2C C++ adapter that can discover muxes and detect slot hardware presence.

## Added

- `cpp_system/include/filament/hardware/i2c_bus.hpp`
- `cpp_system/include/filament/hardware/linux_i2c_bus.hpp`
- `cpp_system/include/filament/hardware/tca9548a_mux.hpp`
- `cpp_system/include/filament/hardware/hardware_adapter.hpp`
- `cpp_system/include/filament/hardware/linux_hardware_adapter.hpp`
- `cpp_system/src/hardware/linux_i2c_bus.cpp`
- `cpp_system/src/hardware/tca9548a_mux.cpp`
- `cpp_system/src/hardware/linux_hardware_adapter.cpp`
- `cpp_system/examples/hardware_probe.cpp`

## What works now

- Open `/dev/i2c-<bus>` in C++.
- Probe PCA9548 addresses.
- Select mux channel and probe downstream NAU7802 + PN532 addresses.
- Emit per-slot presence map (`has_scale`, `has_nfc`, `hardware_present`).

## Not yet implemented in this phase

- Full HDC302x decoding (temperature/humidity registers).
- NAU7802 ADC init/read/calibrate register flow.
- PN532 UID read + NTAG payload read/write flow.

## Build and run on Raspberry Pi

```bash
cd cpp_system
cmake -S . -B build
cmake --build build
./build/filament_hw_probe
```

## Next target

Implement `Nau7802Device`, `Pn532Device`, and `Hdc302xDevice` classes in C++ and connect them into `LinuxHardwareAdapter::scan_slots()` + `read_environment()`.
