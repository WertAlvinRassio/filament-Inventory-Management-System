#include "filament/hardware/linux_hardware_adapter.hpp"

#include <iostream>

int main() {
    filament::hardware::LinuxHardwareAdapter adapter;
    if (!adapter.initialize()) {
        std::cerr << "Failed to initialize LinuxHardwareAdapter\n";
        return 1;
    }

    const auto env = adapter.read_environment();
    std::cout << "Environment available: "
              << (env.temperature_c.has_value() || env.humidity_rh.has_value() ? "yes" : "no")
              << "\n";

    const auto slots = adapter.scan_slots();
    std::cout << "Slots scanned: " << slots.size() << "\n";
    for (const auto& s : slots) {
        if (!s.hardware_present) {
            continue;
        }
        std::cout << "slot=" << s.slot_id << " scale=" << (s.has_scale ? 1 : 0) << " nfc=" << (s.has_nfc ? 1 : 0) << "\n";
    }

    return 0;
}
