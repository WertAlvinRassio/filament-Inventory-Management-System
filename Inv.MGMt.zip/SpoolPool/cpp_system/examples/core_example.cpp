#include "filament/inventory_service.hpp"

#include <iostream>

int main() {
    filament::InventoryService svc(48);

    filament::SlotState slot;
    slot.slot_id = 0;
    slot.hardware_present = true;
    slot.has_scale = true;
    slot.has_nfc = true;
    slot.uid = std::string("ABCDEF");
    slot.gross_weight = 750.0;
    slot.weight = 550.0;
    slot.tare = 200.0;

    svc.upsert_sensor_snapshot(slot);
    const auto ok = svc.apply_program_nfc(0, "Hatchbox", "Black", "PLA", 200.0);

    std::cout << "program_nfc: " << (ok ? "ok" : "fail") << "\n";
    std::cout << "slots: " << svc.snapshot().size() << "\n";
    return 0;
}
