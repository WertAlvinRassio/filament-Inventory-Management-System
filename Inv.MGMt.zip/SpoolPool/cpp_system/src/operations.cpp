#include "filament/operations.hpp"

#include <algorithm>
#include <cmath>
#include <ctime>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>

namespace filament {
namespace {

std::string trim(const std::string& in) {
    const auto start = in.find_first_not_of(" \t\n\r");
    if (start == std::string::npos) {
        return "";
    }
    const auto end = in.find_last_not_of(" \t\n\r");
    return in.substr(start, end - start + 1);
}

std::vector<std::string> split(const std::string& in, char delim) {
    std::vector<std::string> out;
    std::stringstream ss(in);
    std::string part;
    while (std::getline(ss, part, delim)) {
        out.push_back(part);
    }
    return out;
}

std::string iso_now_utc() {
    const auto now = std::time(nullptr);
    std::tm tm{};
#if defined(_WIN32)
    gmtime_s(&tm, &now);
#else
    gmtime_r(&now, &tm);
#endif
    std::ostringstream ss;
    ss << std::put_time(&tm, "%Y-%m-%dT%H:%M:%SZ");
    return ss.str();
}

}  // namespace

std::string clamp_text(const std::string& text, std::size_t max_len) {
    const auto t = trim(text);
    if (t.size() <= max_len) {
        return t;
    }
    return t.substr(0, max_len);
}

std::string calibration_status(const std::string& last_calibrated) {
    // Scaffold behavior aligned with current UI contract.
    // Detailed timestamp parsing is intentionally delegated to Python bridge for now.
    if (trim(last_calibrated).empty()) {
        return "Not calibrated";
    }
    return "Calibrated";
}

NfcParseResult parse_nfc_payload(const std::string& payload) {
    NfcParseResult out;
    const auto txt = trim(payload);
    if (txt.empty()) {
        return out;
    }

    const auto parts = split(txt, '|');
    if (parts.size() >= 3 && !trim(parts[0]).empty() && !trim(parts[1]).empty() && !trim(parts[2]).empty()) {
        out.brand = trim(parts[0]);
        out.color = trim(parts[1]);
        out.type = trim(parts[2]);
        out.parsed_any = true;
    }
    if (parts.size() >= 4 && !trim(parts[3]).empty()) {
        try {
            out.tare = std::stod(parts[3]);
        } catch (...) {
            out.tare = std::nullopt;
        }
    }

    out.nfc_needs_programming = !out.parsed_any;
    return out;
}

std::string build_nfc_payload(const std::string& brand, const std::string& color, const std::string& type, const std::optional<double>& tare) {
    std::ostringstream ss;
    ss << clamp_text(brand.empty() ? "Unknown" : brand)
       << "|"
       << clamp_text(color.empty() ? "N/A" : color)
       << "|"
       << clamp_text(type.empty() ? "N/A" : type)
       << "|";

    if (tare.has_value()) {
        std::ostringstream t;
        t << std::fixed << std::setprecision(2) << *tare;
        auto s = t.str();
        while (!s.empty() && s.back() == '0') {
            s.pop_back();
        }
        if (!s.empty() && s.back() == '.') {
            s.pop_back();
        }
        ss << s;
    }

    return ss.str();
}

void compute_weight(SlotState& slot, std::optional<double> raw) {
    if (!raw.has_value() || !slot.has_scale) {
        slot.gross_weight = 0.0;
        slot.weight = 0.0;
        return;
    }

    const auto counts_per_g = slot.config.calibration_factor;
    auto gross = 0.0;
    if (counts_per_g != 0.0) {
        gross = (*raw - slot.config.zero_offset_raw) / counts_per_g;
    }
    if (gross < 0.0 && gross > -50.0) {
        gross = 0.0;
    }

    if (gross < 0.0) {
        gross = 0.0;
    }
    slot.gross_weight = gross;

    // Apply tare only when a tag UID is currently present.
    const auto tare = slot.uid.has_value() ? slot.tare.value_or(0.0) : 0.0;
    slot.weight = slot.gross_weight - tare;
    if (slot.weight < 0.0) {
        slot.weight = 0.0;
    }

    if (slot.gross_weight > 0.0 || slot.uid.has_value()) {
        slot.is_active = true;
    }
}

bool requires_new_roll_check(const SlotState& slot) {
    return slot.gross_weight >= 10.0 && (!slot.uid.has_value() || slot.nfc_needs_programming);
}

CalibrationResult validate_calibration(double raw, double zero, double known_weight) {
    CalibrationResult out;
    out.known_weight = known_weight;
    out.raw = raw;
    out.zero = zero;

    if (known_weight <= 0.0) {
        out.error = "known_weight must be > 0";
        return out;
    }
    if (raw == 0.0) {
        out.error = "Unable to read load cell";
        return out;
    }
    if (zero == 0.0) {
        out.error = "Zero not set. Remove all weight, wait 2-3s, then click Zero Scale.";
        return out;
    }

    out.delta = raw - zero;
    if (std::abs(out.delta) < 200.0) {
        out.error = "Reading change too small/unstable";
        out.hint = "Make sure the known weight is actually on the platform (not touching frame), wait 3-5s, then try again. If delta stays near 0, the NAU7802 is not seeing the bridge signal (wiring/E+/E-/A+/A- or mechanical mount).";
        return out;
    }

    out.factor = out.delta / known_weight;
    if (out.factor == 0.0) {
        out.error = "Bad calibration factor";
        return out;
    }

    out.success = true;
    return out;
}

}  // namespace filament
