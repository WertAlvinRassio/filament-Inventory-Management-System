#include "filament/hardware/tca9548a_mux.hpp"

namespace filament::hardware {

Tca9548aMux::Tca9548aMux(II2cBus& bus, uint8_t address) : bus_(bus), address_(address) {}

bool Tca9548aMux::deselect_all() {
    return bus_.write_bytes(address_, {0x00});
}

bool Tca9548aMux::select_channel(uint8_t channel) {
    if (channel > 7) {
        return false;
    }
    const uint8_t mask = static_cast<uint8_t>(1u << channel);
    return bus_.write_bytes(address_, {mask});
}

bool Tca9548aMux::probe_on_channel(uint8_t channel, uint8_t device_address) {
    if (!select_channel(channel)) {
        return false;
    }
    return bus_.probe(device_address);
}

}  // namespace filament::hardware
