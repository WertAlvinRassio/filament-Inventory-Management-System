#include "filament/hardware/linux_i2c_bus.hpp"

#include <cerrno>
#include <string>

#if defined(__linux__)
#include <fcntl.h>
#include <linux/i2c-dev.h>
#include <sys/ioctl.h>
#include <unistd.h>
#endif

namespace filament::hardware {

LinuxI2cBus::~LinuxI2cBus() {
    close();
}

bool LinuxI2cBus::open(int bus_number) {
    close();

#if defined(__linux__)
    const auto path = std::string("/dev/i2c-") + std::to_string(bus_number);
    fd_ = ::open(path.c_str(), O_RDWR);
    has_addr_ = false;
    return fd_ >= 0;
#else
    (void)bus_number;
    return false;
#endif
}

void LinuxI2cBus::close() {
#if defined(__linux__)
    if (fd_ >= 0) {
        ::close(fd_);
    }
#endif
    fd_ = -1;
    has_addr_ = false;
}

bool LinuxI2cBus::is_open() const {
    return fd_ >= 0;
}

bool LinuxI2cBus::set_slave_address(uint8_t address) {
#if defined(__linux__)
    if (!is_open()) {
        return false;
    }

    if (has_addr_ && current_addr_ == address) {
        return true;
    }

    if (::ioctl(fd_, I2C_SLAVE, static_cast<int>(address)) < 0) {
        return false;
    }

    current_addr_ = address;
    has_addr_ = true;
    return true;
#else
    (void)address;
    return false;
#endif
}

bool LinuxI2cBus::probe(uint8_t address) {
#if defined(__linux__)
    if (!set_slave_address(address)) {
        return false;
    }

    // Zero-byte write probe: behaves similarly to Python bus writeto(address, b"").
    const auto n = ::write(fd_, nullptr, 0);
    return n >= 0;
#else
    (void)address;
    return false;
#endif
}

bool LinuxI2cBus::write_bytes(uint8_t address, const std::vector<uint8_t>& data) {
#if defined(__linux__)
    if (!set_slave_address(address)) {
        return false;
    }

    if (data.empty()) {
        return probe(address);
    }

    const auto n = ::write(fd_, data.data(), data.size());
    return n == static_cast<ssize_t>(data.size());
#else
    (void)address;
    (void)data;
    return false;
#endif
}

bool LinuxI2cBus::read_bytes(uint8_t address, std::vector<uint8_t>& out, std::size_t size) {
#if defined(__linux__)
    if (!set_slave_address(address)) {
        return false;
    }

    out.assign(size, 0);
    const auto n = ::read(fd_, out.data(), size);
    return n == static_cast<ssize_t>(size);
#else
    (void)address;
    (void)out;
    (void)size;
    return false;
#endif
}

bool LinuxI2cBus::write_then_read(
    uint8_t address,
    const std::vector<uint8_t>& tx,
    std::vector<uint8_t>& rx,
    std::size_t rx_size
) {
    if (!write_bytes(address, tx)) {
        return false;
    }
    return read_bytes(address, rx, rx_size);
}

}  // namespace filament::hardware
