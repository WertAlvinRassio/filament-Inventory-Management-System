#include "filament/hardware/linux_hardware_adapter.hpp"

namespace filament::hardware {

LinuxHardwareAdapter::LinuxHardwareAdapter(LinuxHardwareConfig cfg) : cfg_(std::move(cfg)) {}

bool LinuxHardwareAdapter::initialize() {
    if (!bus_.open(cfg_.i2c_bus_number)) {
        initialized_ = false;
        return false;
    }

    muxes_.clear();
    for (const auto addr : cfg_.mux_addresses) {
        if (!bus_.probe(addr)) {
            continue;
        }

        MuxRef ref;
        ref.address = addr;
        ref.mux = std::make_unique<Tca9548aMux>(bus_, addr);
        ref.mux->deselect_all();
        muxes_.push_back(std::move(ref));
    }

    initialized_ = !muxes_.empty();
    return initialized_;
}

EnvReading LinuxHardwareAdapter::read_environment() {
    EnvReading env;
    if (!initialized_) {
        return env;
    }

    if (cfg_.hdc302x_mux_index < 0 || cfg_.hdc302x_mux_index >= static_cast<int>(muxes_.size())) {
        return env;
    }

    auto& mux = muxes_[cfg_.hdc302x_mux_index].mux;
    if (!mux->probe_on_channel(static_cast<uint8_t>(cfg_.hdc302x_channel), cfg_.hdc302x_address)) {
        return env;
    }

    // Placeholder: raw HDC302x decode goes here in the next step.
    // Keeping null values allows API compatibility with existing frontend.
    return env;
}

std::vector<SlotHardwareSample> LinuxHardwareAdapter::scan_slots() {
    std::vector<SlotHardwareSample> out;
    if (!initialized_) {
        return out;
    }

    for (int mux_index = 0; mux_index < static_cast<int>(muxes_.size()); ++mux_index) {
        auto& mux = muxes_[mux_index].mux;

        for (int channel = 0; channel < 8; ++channel) {
            // Skip reserved environmental sensor path.
            if (mux_index == cfg_.hdc302x_mux_index && channel == cfg_.hdc302x_channel) {
                continue;
            }

            const auto slot_id = mux_index * 8 + channel;

            const bool has_scale = mux->probe_on_channel(static_cast<uint8_t>(channel), cfg_.nau7802_address);
            const bool has_nfc = mux->probe_on_channel(static_cast<uint8_t>(channel), cfg_.pn532_address);

            SlotHardwareSample sample;
            sample.slot_id = slot_id;
            sample.has_scale = has_scale;
            sample.has_nfc = has_nfc;
            sample.hardware_present = has_scale || has_nfc;

            out.push_back(std::move(sample));
        }
    }

    for (auto& m : muxes_) {
        m.mux->deselect_all();
    }

    return out;
}

}  // namespace filament::hardware
