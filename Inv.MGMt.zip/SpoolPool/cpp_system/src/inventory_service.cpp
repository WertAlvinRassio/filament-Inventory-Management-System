#include "filament/inventory_service.hpp"
#include "filament/operations.hpp"

#include <algorithm>

namespace filament {

InventoryService::InventoryService(int slot_count) {
    for (int i = 0; i < slot_count; ++i) {
        SlotState s;
        s.slot_id = i;
        slots_[i] = s;
    }
}

std::vector<SlotState> InventoryService::snapshot() const {
    std::vector<SlotState> out;
    out.reserve(slots_.size());
    for (const auto& [id, s] : slots_) {
        (void)id;
        out.push_back(s);
    }
    return out;
}

std::optional<SlotState> InventoryService::get_slot(int slot_id) const {
    const auto it = slots_.find(slot_id);
    if (it == slots_.end()) {
        return std::nullopt;
    }
    return it->second;
}

bool InventoryService::upsert_sensor_snapshot(const SlotState& incoming) {
    const auto it = slots_.find(incoming.slot_id);
    if (it == slots_.end()) {
        return false;
    }

    auto& slot = it->second;
    slot.hardware_present = incoming.hardware_present;
    slot.has_scale = incoming.has_scale;
    slot.has_nfc = incoming.has_nfc;
    slot.uid = incoming.uid;
    slot.last_error = incoming.last_error;

    if (incoming.tare.has_value()) {
        slot.tare = incoming.tare;
    }
    if (!incoming.brand.empty()) {
        slot.brand = incoming.brand;
    }
    if (!incoming.color.empty()) {
        slot.color = incoming.color;
    }
    if (!incoming.type.empty()) {
        slot.type = incoming.type;
    }

    slot.config.calibration_factor = incoming.config.calibration_factor;
    slot.config.zero_offset_raw = incoming.config.zero_offset_raw;
    slot.config.last_calibrated = incoming.config.last_calibrated;

    slot.gross_weight = incoming.gross_weight;
    slot.weight = incoming.weight;
    slot.is_active = incoming.is_active;
    slot.nfc_needs_programming = incoming.nfc_needs_programming;

    return true;
}

bool InventoryService::apply_program_nfc(int slot_id, const std::string& brand, const std::string& color, const std::string& type, std::optional<double> tare) {
    const auto it = slots_.find(slot_id);
    if (it == slots_.end()) {
        return false;
    }

    auto& slot = it->second;
    if (!slot.uid.has_value()) {
        return false;
    }

    slot.brand = clamp_text(brand.empty() ? slot.brand : brand);
    slot.color = clamp_text(color.empty() ? slot.color : color);
    slot.type = clamp_text(type.empty() ? slot.type : type);
    slot.tare = tare.has_value() ? tare : slot.tare;
    slot.nfc_needs_programming = false;
    slot.is_active = true;
    return true;
}

bool InventoryService::apply_replace_spool(int slot_id, double full_roll_g, std::optional<double> manual_tare) {
    const auto it = slots_.find(slot_id);
    if (it == slots_.end()) {
        return false;
    }

    auto& slot = it->second;
    const auto tare = manual_tare.has_value()
        ? std::max(0.0, *manual_tare)
        : std::max(0.0, slot.gross_weight - full_roll_g);

    return apply_program_nfc(slot_id, slot.brand, slot.color, slot.type, tare);
}

std::optional<double> InventoryService::apply_zero(int slot_id, double raw) {
    const auto it = slots_.find(slot_id);
    if (it == slots_.end()) {
        return std::nullopt;
    }

    auto& slot = it->second;
    if (!slot.has_scale || raw == 0.0) {
        return std::nullopt;
    }

    slot.config.zero_offset_raw = raw;
    return slot.config.zero_offset_raw;
}

std::optional<CalibrationResult> InventoryService::apply_calibrate(int slot_id, double known_weight, double raw) {
    const auto it = slots_.find(slot_id);
    if (it == slots_.end()) {
        return std::nullopt;
    }

    auto& slot = it->second;
    if (!slot.has_scale) {
        CalibrationResult out;
        out.error = "Load cell not detected";
        return out;
    }

    auto result = validate_calibration(raw, slot.config.zero_offset_raw, known_weight);
    if (result.success) {
        slot.config.calibration_factor = result.factor;
        // Keep this in sync with Python for now; timestamp source will move in phase 2.
        slot.config.last_calibrated = "set-by-adapter";
    }

    return result;
}

}  // namespace filament
